#include <SDL.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;

// Globální proměnná pro kreslení (aby studenti nemuseli řešit ukazatele v parametrech)
SDL_Renderer *renderer = NULL;


void nakresli_kruh(int x, int y, float radius, int r, int g, int b) {
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
    double pi = 3.14159265359;
    int precision = 400;
    double step = pi / (double)(precision - 1);
    for (int i = 0; i < precision; i++) {
        float x1 = cos(-i * step) * radius + x;
        float y1 = sin(-i * step) * radius + y;
        float x2 = cos(i * step) * radius + x;
        float y2 = sin(i * step) * radius + y;
        SDL_RenderDrawLine(renderer, x1, y1, x2, y2);
    }
}
// Funkce pro vykreslení plného obdélníku
void nakresli_blok(int x, int y, int sirka, int vyska, int r, int g, int b) {
    // Nápověda k SDL příkazům:
    SDL_SetRenderDrawColor(renderer, r, g, b, 255);
    SDL_Rect rect = {x, y, sirka, vyska};
    SDL_RenderFillRect(renderer, &rect);
}

// Úkol 1: Napište funkci pro kresleni pěkného auta pomocí nakresli_blok() a nakresli_kruh()
void nakresli_auto(int x, int y, int velikost) {
    // ZDE DOPLŇTE KÓD:
    // Příklad pro blok houkačky s náhodnou barvou:
    nakresli_blok(x+50, y-30, 10, 10, rand() & 255, rand() & 255, rand() & 255);
    nakresli_blok(x, y-20, 100, 50, 255, 255, 255);
    nakresli_kruh(x+15,y+25,15, 200,200,200);
    nakresli_kruh(x+85,y+25,15, 200,200,200);

}


int main(int argc, char *argv[]) {
    // Inicializace SDL (ignorujte)
    if (SDL_Init(SDL_INIT_VIDEO) < 0) return 1;
    SDL_Window *window = SDL_CreateWindow("Proceduralni Mesto", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                                          WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    srand((unsigned int) time(NULL));

    bool running = true;
    SDL_Event event;
    bool redraw = true;
    int x=0;
    while (running) {
        // Zpracování zavření okna a jakékoli klávesy pro redraw:
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) running = 0;
            if (event.type == SDL_KEYDOWN) redraw = !redraw;
        }

        if (redraw) {
            // Vymazání obrazovky (noční obloha):
            SDL_SetRenderDrawColor(renderer, 15, 15, 30, 255);
            SDL_RenderClear(renderer);
            // =====================================================================
            // ÚKOL 2: kresli několik aut v pohybu
            // =====================================================================
            nakresli_auto(x,50,100);
            x=(x+2)%512;
            // ZDE DOPLŇTE KÓD:

            // =====================================================================
            // ÚKOL 3: Smaž primitivní obdélníky, místo nich volej funkci nakresli_dum(...)
            // Tuto funkci musíš napřed samostatně naprogramovat.
            // =====================================================================
            // ZDE DOPLŇTE KÓD:

            nakresli_blok(50, 300, 100, 200, 255, 255, 0);
            nakresli_blok(155, 250, 100, 250, 255, 255, 255);
            nakresli_blok(260, 200, 100, 300, 200, 255, 200);

            SDL_RenderPresent(renderer);
        }

    }

    // 3. Úklid paměti na konci programu
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}
