/**
 * @file main.c
 * @author Tomáš Lecián
 * @brief Soubor obsahuje příklad implmementace algoritmu průchodu do hloubky (DFS).
 * @detail Robot Karel má za úkol, najít všechny značky v bludišti (ve svém městě).
 */

#include <stdio.h>
#include <stdlib.h>
#include <KnihovnaRobotakarla.h>
#include <stdbool.h>


//============ Deklarace globalnich promennych, struktur vyctovych typu a konstant ========================================

/**
 * @brief Makro definující velikost zásobníku
 */
#define VELIKOST_ZASOBNIKU 100

/**
 * @brief Označení polí města vzhledem ke grafu
 */
typedef enum{
    PRIMA_CHODBA, /**< Označení hrany grafu */
    KRIZOVATKA, /**< Označení uzlu grafu */
    SLEPA_CHODBA /**< Označení koncového uzlu grafu */
} statusObjevu;

/**
 * @brief Orientační označení možných chodeb křižovatky.
 */
typedef enum{
    NENAVSTIVENA, /**< Chodba tímto směrem nebyla ještě prozkoumána */
    NAVSTIVENA, /**< Chodba byla tímto směrem jíž celá prozkoumána */
    PRICHOD, /**< Touto chodbou Karel přišel na aktuální křižovatku */
    ZED /**< Tímto směrem není žádná chodba */
} statusOdbocky;

/**
 * @brief Souřadnice definující polohu ve městě
 */
typedef struct{
    int x; /**< Souřadnice x */
    int y; /**< Souřadnice y */
} souradnice;

/**
 * @brief Charakterizuje jednotlivé křižovvatky bludiště.
 */
typedef struct{
    souradnice pozice; /**< Poloha křižovatky v bludišti */
    statusOdbocky severniOdbocka; /**< Pomocné označení odbočky na severu */
    statusOdbocky jizniOdbocka; /**< Pomocné označení odbočky na jihu */
    statusOdbocky vychodniOdbocka; /**< Pomocné označení odbočky na vychodě */
    statusOdbocky zapadniOdbocka; /**< Pomocné označení odbočky na západě */
} krizovatka;

/**
 * @brief Charakterizuje zásobník.
 */
typedef struct{
    int vrchol; /**< Index pole \b prvky  označující vrchol zásobníku */
    krizovatka *prvky[VELIKOST_ZASOBNIKU]; /**< Pole představující jednotlivé prvky zásobníku */
} zasobnik;

bool gStart = true; /**< Globální proměnná \gStart označuje první volání funkce \b algoritmusProhledavani */


//============ Deklarace pomocnych funkci =================================================================================

void algoritmusProhledavani(souradnice *aktualniSouradnice, zasobnik *zasob);
bool vlozit(krizovatka *novyUzel, zasobnik *zasob);
void vyjmout(zasobnik *zasob);
statusObjevu jeZdeKrizovatka(souradnice *aktualniSouradnice);
statusObjevu chuzeDokudNeniKrizovatkaNeboSlepaUlice(souradnice *aktualniSouradnice);
void prepocetSouradnic(souradnice *aktualniSouradnice);
krizovatka *vytvoritNovyUzel(souradnice *aktualniSouradnice, bool prvniKrizovatka);
krizovatka *znamTutoKrizovatku(souradnice *aktualniSouradnice, zasobnik *zasob);
void oznacitOdbocku(krizovatka *krizovatkaKOznaceni, statusOdbocky status);
void celemVzad();
void vyberCestyNaKrizovatce(souradnice *aktualniSouradnice, zasobnik *zasob);
void natocitSeSmeremOdkudJsemPrisel(zasobnik *zasob);


//============ Pomocne funkce =============================================================================================

/**
 * @brief Umožňuje vložit novou křižovatku na zásobník.
 * @param novyUzel je pointer na křižovatku, která se má vložit vo zásobníku.
 * @param Zasob je pointer na zásobník do kterého chceme vkládat.
 * @return true byla-li nová křižovatka vložena na zásobník úspěšně.
 */
bool vlozit(krizovatka *novyUzel, zasobnik *zasob){
    if(zasob->vrchol == VELIKOST_ZASOBNIKU - 1){
        printf("\nChyba zasosbniku - zasobnik je plny, nelze vlozit dalsi prvek. Program se ukonci po stiskneti klavesy Enter");
        getchar();
        exit(1);
        return false;
    }
    else{
        zasob->vrchol += 1;
        zasob->prvky[zasob->vrchol] = novyUzel;
        return true;
    }
}

/**
 * @brief Smaze křizovatku na vrcholu zásobníku a sníží vrchol zásobníku o jedničku.
 * @param zasob zásobník ve kterém provádíme změnu.
 */
void vyjmout(zasobnik *zasob){
    if(zasob->vrchol >= 0){
        free(zasob->prvky[zasob->vrchol]);
        zasob->prvky[zasob->vrchol] = NULL;
        zasob->vrchol -= 1;
    }
    else{
        printf("\nChyba zasobniku - odebrali jste neexistujici prvek. Program se ukonci po stiskneti klavesy Enter");
        getchar();
        exit(1);
    }
}

/**
 * @brief Vytvoří v paměti strukturu křižovatky na které Karel aktuálně stojí.
 * @param aktualniSouradnice jsou souřadnice křižovatky na které Karel stojí.
 * @param prvniKrizovatka označuje že se jedná o první křižovatku na kterou Karel narazil a musí prohledávat všechny její možné odbočky.
 * @return Návratovou hodnotou je pointer na strukturu v paměti.
 *
 * Odbočce ze které Karel na tuto křižovatku přišel je přiřazeno označení \b PRICHOD ostatním odbočkám (směrům) \b NENAVSTIVENA.
 */
krizovatka *vytvoritNovyUzel(souradnice *aktualniSouradnice, bool prvniKrizovatka){
    krizovatka *uzel = (krizovatka*) malloc(sizeof(krizovatka));
    if(uzel == NULL){
        printf("\nChyba pri alokaci pameti");
        getchar();
        exit(EXIT_FAILURE);
    }
    if(prvniKrizovatka){
        uzel->severniOdbocka = NENAVSTIVENA;
        uzel->jizniOdbocka = NENAVSTIVENA;
        uzel->vychodniOdbocka = NENAVSTIVENA;
        uzel->zapadniOdbocka = NENAVSTIVENA;
    }
    else{
        if(jeOtocenNaSever()){
            uzel->jizniOdbocka = PRICHOD;
        }
        else{
            uzel->jizniOdbocka = NENAVSTIVENA;
        }
        if(jeOtocenNaJih()){
            uzel->severniOdbocka = PRICHOD;
        }
        else{
            uzel->severniOdbocka = NENAVSTIVENA;
        }
        if(jeOtocenNaVychod()){
            uzel->zapadniOdbocka = PRICHOD;
        }
        else{
            uzel->zapadniOdbocka = NENAVSTIVENA;
        }
        if(jeOtocenNaZapad()){
            uzel->vychodniOdbocka = PRICHOD;
        }
        else{
            uzel->vychodniOdbocka = NENAVSTIVENA;
        }
    }
    uzel->pozice.x = aktualniSouradnice->x;
    uzel->pozice.y = aktualniSouradnice->y;
    return uzel;
}

/**
 * @brief Zjišťuje jaký význam má dané místo bludiště, vzhledem ke grafu bludiště.
 * @param ktualniSouradnice Souřadnice místa které je testováno.
 * @return Návratovou hodnotou je \b KRIZOVATKA jedná-li se o uzel grafu, \b SLEPA_ULICE je-li to koncový uzel grafu, nebo \n PRIMA_ULICE jedlá-li se o hranu grafu.
 */
statusObjevu jeZdeKrizovatka(souradnice *aktualniSouradnice){
    int pocetOdbocek = 0;
    if(!jePredemnouZed()){
        pocetOdbocek++;
    }
    if(!jeVlevoZed()){
        pocetOdbocek++;
    }
    if(!jeVpravoZed()){
        pocetOdbocek++;
    }
    if(pocetOdbocek == 0){
        return SLEPA_CHODBA;
    }
    if(pocetOdbocek > 1){
        return KRIZOVATKA;
    }
    return PRIMA_CHODBA;
}

/**
 * @brief Karel půjde chodbou ve směru ve kterém je natočen, dokun nenarazí na uzel grafu.
 * @param aktualniSouradnice Souřadnice místa na kterém Karel stojí.
 * @return Funkce vrací hodnoty \b KRIZOVATKA, nebo \b SLEPA_CHODBA podle typu uzlu grafu ve kterém se Karel nachází.
 */
statusObjevu chuzeDokudNeniKrizovatkaNeboSlepaUlice(souradnice *aktualniSouradnice){
    statusObjevu objev;
    while((objev = jeZdeKrizovatka(aktualniSouradnice)) == PRIMA_CHODBA){
        //Nez udela Karel krok, zjisti jesi nestoji na nejake znace:
        while(jeZdeZnacka()){
            zvedniZnacku();
        }
        //Karel udela krok smerem kde je volno:
        if(!jePredemnouZed()){
            krok();
        }
        else{
            if(!jeVlevoZed()){
                vlevoVbok();
                krok();
            }else{
                vlevoVbok();
                vlevoVbok();
                vlevoVbok();
                krok();
            }
        }
        prepocetSouradnic(aktualniSouradnice);
    }
    return objev;
}

/**
 * @brief Aktualizace souřadnic, kterou je nutno provést po každé Karlově změně polohy.
 * @param aktualniSouradnice Pointer na strukturu ve které se uchovávají aktuální souřadnice robota Karla.
 */
void prepocetSouradnic(souradnice *aktualniSouradnice){
    if(jeOtocenNaSever()){
        aktualniSouradnice->y++;
    }
    if(jeOtocenNaJih()){
        aktualniSouradnice->y--;
    }
    if(jeOtocenNaVychod()){
        aktualniSouradnice->x++;
    }
    if(jeOtocenNaZapad()){
        aktualniSouradnice->x--;
    }
    printf("\nKrok na souradnice: x = %d, y = %d", aktualniSouradnice->x,  aktualniSouradnice->y);
}

/**
 * @brief Kontrola zda křižovatka na které Karel stojí, se nachází v zásobníku.
 * @param aktualniSouradnice Souřadnice křižovatky na které karel aktuálně stojí.
 * @param zasob Zásobník který se má prohledávat.
 * @return Vrací \b NULL pukud se daná křižovatka na zásobníku \b zasob nenachází. Jinak vrací pointer na strukturu hledané křižovatky.
 */
krizovatka *znamTutoKrizovatku(souradnice *aktualniSouradnice, zasobnik *zasob){
    int index = 0;
    while(index <= zasob->vrchol){
       if(zasob->prvky[index]->pozice.x == aktualniSouradnice->x){
           if(zasob->prvky[index]->pozice.y == aktualniSouradnice->y){
                return zasob->prvky[index];
           }
       }
       index++;
    }
    return NULL;
}

/**
 * @brief Označení odbočky křižovatky, ke které je karel zády, tj. odkud na ni přišel.
 * @param krizovatkaKOznaceni Pointer na struktury křižovatky na které se má označit odbočka.
 * @param status Typ označení odbočky.
 */
void oznacitOdbocku(krizovatka *krizovatkaKOznaceni, statusOdbocky status){
    //Oznacuje krizovatku predavanou parametrem statusem taktez predavany parametrem
    if(jeOtocenNaSever()){
        krizovatkaKOznaceni->jizniOdbocka = status;
    }
    if(jeOtocenNaJih()){
        krizovatkaKOznaceni->severniOdbocka = status;
    }
    if(jeOtocenNaVychod()){
        krizovatkaKOznaceni->zapadniOdbocka = status;
    }
    if(jeOtocenNaZapad()){
        krizovatkaKOznaceni->vychodniOdbocka = status;
    }
}

/**
 * @brief Karel se otočí o 180°.
 */
void celemVzad(){
    vlevoVbok();
    vlevoVbok();
}

/**
 * @brief Karel vybere první nenavštívenou chodbu křižovatky na vrcholu zásobníku a vydá se po této chodbě.
 * @param aktualniSouradnice Souřadnice, kde se Karel aktuálně v bludišti nachází.
 * @param zasob Zásobník ze kterého se bere křižovatka.
 *
 * Od východu proti směru hodinových ručiček se hledá první nenavštívená chodba. Při shodě se Karel touto cestou vydá (volá se funkce \b algoritmusProhledavani)
 */
void vyberCestyNaKrizovatce(souradnice *aktualniSouradnice, zasobnik *zasob){
    printf("\nOtacim se na sever pro urceni odbocky");
    while(!jeOtocenNaSever()){
        vlevoVbok();
    }
    //Karel testuje jednotlive svetove strany a v pripade potreby spousti novy agoritmus pro prohledani dalsi cesty:
    //Vychod:
    if(zasob->prvky[zasob->vrchol]->vychodniOdbocka == NENAVSTIVENA){
        if(!jeVpravoZed()){
            printf("\nOtacim se na vychod - spoustim novy algoritmus prohledavani odbocky");
            vlevoVbok();
            vlevoVbok();
            vlevoVbok();
            krok();
            prepocetSouradnic(aktualniSouradnice);
            algoritmusProhledavani(aktualniSouradnice, zasob);
        }
        else{
            printf("\nNa vychode je zed");
            zasob->prvky[zasob->vrchol]->vychodniOdbocka = ZED;
        }
    }
    //Sever
    if(zasob->prvky[zasob->vrchol]->severniOdbocka == NENAVSTIVENA){
        if(!jePredemnouZed()){
            printf("\nJdu na sever - spoustim novy algoritmus prohledavani odbocky");
            krok();
            prepocetSouradnic(aktualniSouradnice);
            algoritmusProhledavani(aktualniSouradnice, zasob);
        }
        else{
            printf("\nNa severu je zed");
            zasob->prvky[zasob->vrchol]->severniOdbocka = ZED;
        }
    }
    //Zapad
    if(zasob->prvky[zasob->vrchol]->zapadniOdbocka == NENAVSTIVENA){
        if(!jeVlevoZed()){
            printf("\nOtacim se na zapad - spoustim novy algoritmus prohledavani odbocky");
            vlevoVbok();
            krok();
            prepocetSouradnic(aktualniSouradnice);
            algoritmusProhledavani(aktualniSouradnice, zasob);
        }
        else{
            printf("\nNa zapade je zed");
            zasob->prvky[zasob->vrchol]->zapadniOdbocka = ZED;
        }
    }
    //Jih
    if(zasob->prvky[zasob->vrchol]->jizniOdbocka == NENAVSTIVENA){
        vlevoVbok();
        if(!jeVlevoZed()){
            printf("\nOtacim se na jih - spoustim novy algoritmus prohledavani odbocky");
            vlevoVbok();
            krok();
            prepocetSouradnic(aktualniSouradnice);
            algoritmusProhledavani(aktualniSouradnice, zasob);
        }
        else{
            printf("\nNa jihu je zed");
            zasob->prvky[zasob->vrchol]->jizniOdbocka = ZED;
        }
    }
}

/**
 * @brief Karel se na křižovatce otočí směrem k chodbě, kterou na tuto křižovatku poprvé přišel.
 * @param zasob Zásobní z jehož vrcholu je daná křižovatka.
 */
void natocitSeSmeremOdkudJsemPrisel(zasobnik *zasob){
    printf("\nProzkoumal jsem vsechny mozne cesty krizovatky a vracim se");
    if(zasob->prvky[zasob->vrchol]->vychodniOdbocka == PRICHOD){
        while(!jeOtocenNaVychod()){
            vlevoVbok();
        }
    }
    if(zasob->prvky[zasob->vrchol]->severniOdbocka == PRICHOD){
        while(!jeOtocenNaSever()){
            vlevoVbok();
        }
    }
    if(zasob->prvky[zasob->vrchol]->zapadniOdbocka == PRICHOD){
        while(!jeOtocenNaZapad()){
            vlevoVbok();
        }
    }
    if(zasob->prvky[zasob->vrchol]->jizniOdbocka == PRICHOD){
        while(!jeOtocenNaJih()){
            vlevoVbok();
        }
    }
}

/**
 * @brief Algoritmus prohledávání grafu do hloubky
 * @param aktualniSouradnice Souřadnice na kterých se Karel nachází.
 * @param zasob Zásobník se kterým má algoritmus pracovat.
 */
void algoritmusProhledavani(souradnice *aktualniSouradnice, zasobnik *zasob){
    //Pokud je poprve spusten algoritmusProhledavani na projiti celeho mesta tak:
    if(gStart){
        //Zjisteni kolik je moznych odbocek z mista kde Karel stoji:
        int i, pocetMoznychCest = 0;
        printf("\nZjistuji kolik je kolem me moznych cest");
        for(i=0; i<4; i++){
            if(!jePredemnouZed()){
                pocetMoznychCest++;
            }
            vlevoVbok();
        }
        //Natoceni nekterou z moznych cest:
        printf("\nNatacim se smerem k nejake chodbe");
        while(jePredemnouZed()){
            vlevoVbok();
        }
        //Pokud Karel stoji na krizovatce natoci se tak aby za sebou měl chodbu jinak udela 1 krok, aby v obou pripadech byl spravne proveden proces zjistovani krizovatky:
        if(pocetMoznychCest >2){
            printf("\nPri staru jsem na krizovatce, otacim se zady k chodbe");
            vlevoVbok();
            vlevoVbok();
        }
        else{
            krok();
            prepocetSouradnic(aktualniSouradnice);
        }
        //Karel zacina na konci slepe chodby a jiz se do ni nemusi nikdy vracet:
        if(pocetMoznychCest == 1){
            gStart = false;
        }
    }
    //Karel pujde chodbou dokud nenarazi na krizovatku, nebo slepou chodbu:
    statusObjevu novyObjev = chuzeDokudNeniKrizovatkaNeboSlepaUlice(aktualniSouradnice);
    krizovatka *aktualniKrizovatka;
    switch(novyObjev){
        case SLEPA_CHODBA:
            //Karel zvedne znacku pokud nejaka je na konci chodby:
            while(jeZdeZnacka()){
                zvedniZnacku();
            }
            //Karel se otoci vzad, pujde zpet na nejblizsi krizovatku a oznacim si na ni odkud na ni prisel:
            printf("\nSlepa ulice - otacim se a jdu zpet");
            celemVzad();
            chuzeDokudNeniKrizovatkaNeboSlepaUlice(aktualniSouradnice);
            if(zasob->vrchol != -1){
                oznacitOdbocku(zasob->prvky[zasob->vrchol], NAVSTIVENA);
                //Karel se otoci na sever pro dalsi urceni mozne cesty:
                printf("\nPo navratu se otacim na sever");
                while(!jeOtocenNaSever()){
                    vlevoVbok();
                }
            }
            break;
        case KRIZOVATKA:
            //Kontrola zda Karel je na teto krizovatce poprve:
            if((aktualniKrizovatka = znamTutoKrizovatku(aktualniSouradnice, zasob)) != NULL){
                //Karel na teto krizovatce neni poprve, oznaci si odkud přišel na tuto krizovatku a pujde smerem odkud prisel na nejblizsi krizovatku:
                printf("\nNa krizovatne nejsem poprve - otacim se a jdu zpet");
                oznacitOdbocku(aktualniKrizovatka, NAVSTIVENA);
                celemVzad();
                krok();
                prepocetSouradnic(aktualniSouradnice);
                chuzeDokudNeniKrizovatkaNeboSlepaUlice(aktualniSouradnice);
                //Karel si oznaci ze prozkoumal dalsi chodbu krizovatky na vrcholu zasobniku:
                oznacitOdbocku(zasob->prvky[zasob->vrchol], NAVSTIVENA);
                printf("\nPo navratu se otacim na sever");
                while(!jeOtocenNaSever()){
                    vlevoVbok();
                }
            }
            //Karel je na teto krizovatce poprve:
            else{
                //Podiva se jestli zde neni znacka:
                while(jeZdeZnacka()){
                    zvedniZnacku();
                }
                //Ulozi si krizovatku na zasobnik:
                vlozit(vytvoritNovyUzel(aktualniSouradnice, gStart), zasob);
                printf("\nNova krizovatka - ukladam si ji na zasobnik. Pocet krizovatek na zasobniku: %d", zasob->vrchol + 1);
                gStart = false;
                //Vybere jednu moznou cestu z krizovatky a vyda se po ni:
                vyberCestyNaKrizovatce(aktualniSouradnice, zasob);
                //Karel jiz prohledal vsechny mozne cesty krizovatky, otoci se smerem odkud na tuto krizovatku prisel:
                natocitSeSmeremOdkudJsemPrisel(zasob);
                //Krizovatku na vrcholu zasobniku zapomene, protoze jiz ji celou prozkoumal:
                vyjmout(zasob);
                //Pokud ma na zasobniku jeste nejakou krizotatku, kterou celou neprozkoumal, tak se na ni vrati, jinka ukonci algoritmusProhledavani prohledavani:
                if(zasob->vrchol >= 0){
                    krok();
                    prepocetSouradnic(aktualniSouradnice);
                    chuzeDokudNeniKrizovatkaNeboSlepaUlice(aktualniSouradnice);
                    oznacitOdbocku(zasob->prvky[zasob->vrchol], NAVSTIVENA);
                    printf("\nOtacim se na sever po prichodu na krizovatku");
                    while(!jeOtocenNaSever()){
                        vlevoVbok();
                    }
                }
            }
            break;
        default:
            break;
    }
    //Tato podminka nastave v pripade narazi-li Karel po spusteni algoritmu jako prvni na slepou chodbu a po otoceni a chuzi az na krizovatku:
    if(gStart){
        gStart = false;
        algoritmusProhledavani(aktualniSouradnice, zasob);
    }
    printf("\nUkoncuji jeden vnozeny algoritmusProhledavani prohledavani");
}


//============ Funkce main ================================================================================================

/**
 * @brief Výchozí funkce programu.
 * @param argc představuje počet argumentů příkazové řádky.
 * @param argv je pole ukazatelů na argumenty příkazové řádky.
 * @return Návratová hodnota 0 značí úspěšné ukončení programu.
 */
int main(int argc, char **argv)
{

    postavitMesto("Bludiste-spleteSeSlepymiKonci.txt");
    //Inicializace zasobniku a pocatecnich souradnic:
    zasobnik stag;
    stag.vrchol = -1;
    souradnice aktualniPozice;
    aktualniPozice.x = 0;
    aktualniPozice.y = 0;

    algoritmusProhledavani(&aktualniPozice, &stag);
    printf("\n\nHOTOVO! Vsechno vim, vsechno znam, vsude jsem byl. Karel");

    zbouratMesto();
    return 0;
}
