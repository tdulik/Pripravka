/**
 * @file main.c
 * @author Tomáš Lecián
 * @brief Soubor obsahuje příklad implmementace vykreslení Pascalova trojuhelniku.
 * @detail Robot Karel má za úkol, pomocí svých značek vykreslit Pascalův trojúhelník.
 */

#include <stdio.h>
#include <KnihovnaRobotaKarla.h>


//============ Deklarace globalnich promennych, struktur a vyctovych typu =================================================



//============ Deklarace pomocnych funkci =================================================================================

void bezpecnyKrok();
void jitVlevo();
void jitVpravo();
void vratitSeZpet();
void pascaluvTrojuhelnik(int pocetRadku);


//============ Pomocne funkce =============================================================================================

/**
 * @brief Je-li volno, udělá Karel krok ve směru ve kterém je natočen.
 *
 * Nachází-li se před karlem zeď. Bude na výstupní konzoli vypsáno varovné hlášení.
 */
void bezpecnyKrok(){
    if(jePredemnouZed()){
        printf("\nNemohu udelat krok, je predemnou zed. Pascaluv trojuhelnik nebude spravne vykresleny!");
    }
    else{
        krok();
    }
}

/**
 * @brief Karel se posune šikmo vlevo dolů.
 *
 * Karel udělá krok vpřed, otočí se vlevo a udělá opět krok vpřed.
 */
void jitVlevo(){
    bezpecnyKrok();
    vlevoVbok();
    bezpecnyKrok();
}

/**
 * @brief Karel se posune vpravo od místa kde se nachází.
 *
 * Otočí se na západ a udělá 2 kroky vpřed.
 */
void jitVpravo(){
    while(!jeOtocenNaZapad()){
        vlevoVbok();
    }
    bezpecnyKrok();
    bezpecnyKrok();
}

/**
 * @brief Karel se vrati na misto odkud na toto místo přišel.
 *
 * Udělá jeden krok na východ a jeden na sever.
 */
void vratitSeZpet(){
    while(!jeOtocenNaVychod()){
        vlevoVbok();
    }
    bezpecnyKrok();
    vlevoVbok();
    bezpecnyKrok();
}

/**
 * @brief Vykreslení Pascalova trojúhelníku.
 * @param pocetRadku udáva počet řádků Pascalova trojúhelníku.
 *
 * Karel se natočí na jih a položí značku. Vydá se vlevo a vpravo a pokaždé se rekurzivně zavolá funkce  pascaluvTrojuhelnik.
 */
void pascaluvTrojuhelnik(int pocetRadku){
    while(!jeOtocenNaJih()){
        vlevoVbok();
    }
    polozZnacku();
    if(pocetRadku > 1){
        jitVlevo();
        pascaluvTrojuhelnik(pocetRadku - 1);
        jitVpravo();
        pascaluvTrojuhelnik(pocetRadku - 1);
        vratitSeZpet();
    }
}


//============ Funkce main ================================================================================================

/**
 * @brief Výchozí funkce programu.
 * @param argc představuje počet argumentů příkazové řádky.
 * @param argv je pole ukazatelů na argumenty příkazové řádky.
 * @return Návratová hodnota 0 značí úspěšné ukončení programu.
 */
int main(int argc, char **argv)
{

    postavitMesto("Mesto-PascaluvTrojuhelnik.txt");

    pascaluvTrojuhelnik(5);
    printf("\nKonec algoritmu");
    zbouratMesto();
    return 0;
}
