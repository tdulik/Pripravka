/**
 * @file main.c
 * @author Tomáš Lecián
 * @brief Soubor obsahuje příklad implmementace algoritmu sledování zdí.
 * @detail Robot Karel má za úkol, najít v bludišti cestu ke svému domečku.
 */

#include <stdio.h>
#include <KnihovnaRobotaKarla.h>

/**
 * @brief Výchozí funkce programu.
 * @param argc představuje počet argumentů příkazové řádky.
 * @param argv je pole ukazatelů na argumenty příkazové řádky.
 * @return Návratová hodnota 0 značí úspěšné ukončení programu.
 */
int main(int argc, char **argv)
{
    postavitMesto("Bludiste-perfektni.txt");
    bool konec = false;

    if(jeZdeDomecek()){
            printf("Jsem doma!");
            konec = true;
        }

    while(!konec){
        if(jeVlevoZed() && !jePredemnouZed()){
            krok();
        }else{
            if(!jeVlevoZed()){
                vlevoVbok();
                krok();
            }else{
                while(!jeVlevoZed() || jePredemnouZed()){
                    vlevoVbok();
                }
                krok();
            }
        }
        if(jeZdeDomecek()){
            printf("Jsem doma!");
            konec = true;
        }

    }
    zbouratMesto();
    return 0;
}