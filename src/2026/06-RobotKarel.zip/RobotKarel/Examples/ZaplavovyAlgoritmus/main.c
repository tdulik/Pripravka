/**
 * @ file main.c
 * @author Tomáš Lecián
 * @brief Soubor obsahuje příklad implmementace záplavového algoritmu.
 * @detail Robot Karel má za úkol, na každe volné políčko ve svém světě položit jednu značku. Zaplavový algoritmus s prohledáváním 4 směrů.
 */

#include <stdio.h>
#include <KnihovnaRobotaKarla.h>


//============ Deklarace globalnich promennych, struktur vyctovych typu a konstant ========================================

int gPocitadloZanoreni = 0; /**<Globalní proměnná reprezentující počet rekurzivních volání funkce \fn vypln.*/

/**
 * @brief Výčtový typ \enum smer reprezentuje světové strany.
 *
 * <b>smer</b> se využívá při určování směru kam se má robot Karel vracet.
 */
typedef enum{
    SEVER, /**< Severní směr. */
    JIH, /**< Jížní směr. */
    VYCHOD, /**< Východní směr. */
    ZAPAD, /**< Západní směr. */
    NIKAM /**< Žádný směr. */
}smer;


//============ Deklarace pomocnych funkci =================================================================================

void vypln(smer iteracniSmer);
void naVychod(int cisloZanoreni);
void naSever(int cisloZanoreni);
void naZapad(int cisloZanoreni);
void naJih(int cisloZanoreni);
void krokZpet();
void vratitSeOdkudJsemZdePrisel(smer danySmer);

//============ Pomocne funkce =============================================================================================

/**
 * @brief Funkce Záplavového algoritmu.
 * @param iteracniSmer představuje směr kterým se robot Karel musí vrátit, aby pokračoval v původní funkci \b vypln
 *
 * Algoritmus se šíří 4 směry. Pro každý směr je definovaná samostatná funkce.
 */
void vypln(smer iteracniSmer){
    gPocitadloZanoreni++;
    smer smerOdkuJsemPrisel = iteracniSmer;
    int cisloZanoreni = gPocitadloZanoreni;
    if(!jeZdeZnacka()){
        polozZnacku();
        naVychod(cisloZanoreni);
        naSever(cisloZanoreni);
        naZapad(cisloZanoreni);
        naJih(cisloZanoreni);
        printf("\n%d. vnoreni - konec vnoreni, vracim se na policko odkud jsem prisel", cisloZanoreni);
        vratitSeOdkudJsemZdePrisel(smerOdkuJsemPrisel);
    }
}

/**
 * @brief Algoritmus prohledávání východního směru aktuální pozice.
 * @param cisloZanoreni udává číslo následujícího volání funkce \b vypln.
 *
 * Karel pokud může udělá krok na východ. Pokud se na daném místě nenachází žádná značka, zavolá se funkce \b vypln
 */
void naVychod(int cisloZanoreni){
    //Natoceni spravnym smerem:
    while(!jeOtocenNaVychod()){
        vlevoVbok();
    }
    //Kontrola zda muzu udelat krok vpred:
    if(!jePredemnouZed()){
        krok();
        //Kontrola zda jsem na tomto miste poprve:
        if(jeZdeZnacka()){
            printf("\n%d. vnoreni - VYCHOD -> krok -> vracim se zpet, zde uz jsme znacku polozil", cisloZanoreni);
            krokZpet();
        }
        else{
            printf("\n%d. vnoreni - VYCHOD -> krok a nove zanoreni", cisloZanoreni);
            vypln(VYCHOD);
        }
    }
    else{
        printf("\n%d. vnoreni - VYCHOD -> zed.", cisloZanoreni);
    }
}

/**
 * @brief Algoritmus prohledávání severního směru aktuální pozice.
 * @param cisloZanoreni udává číslo následujícího volání funkce \b vypln.
 *
 * Karel pokud může udělá krok na sever. Pokud se na daném místě nenachází žádná značka, zavolá se funkce \b vypln
 */
void naSever(int cisloZanoreni){
    while(!jeOtocenNaSever()){
        vlevoVbok();
    }
    if(!jePredemnouZed()){
        krok();
        if(jeZdeZnacka()){
            printf("\n%d. vnoreni - SEVER -> krok -> vracim se zpet, zde uz jsme znacku polozil", cisloZanoreni);
            krokZpet();
        }
        else{
            printf("\n%d. vnoreni - SEVER -> krok a nove zanoreni", cisloZanoreni);
            vypln(SEVER);
        }
    }
    else{
        printf("\n%d. vnoreni - SEVER -> zed.", cisloZanoreni);
    }
}

/**
 * @brief Algoritmus prohledávání západního směru aktuální pozice.
 * @param cisloZanoreni udává číslo následujícího volání funkce \b vypln.
 *
 * Karel pokud může udělá krok na západ. Pokud se na daném místě nenachází žádná značka, zavolá se funkce \b vypln
 */
void naZapad(int cisloZanoreni){
    while(!jeOtocenNaZapad()){
        vlevoVbok();
    }
    if(!jePredemnouZed()){
        krok();
        if(jeZdeZnacka()){
            printf("\n%d. vnoreni - ZAPAD -> krok -> vracim se zpet, zde uz jsme znacku polozil", cisloZanoreni);
            krokZpet();
        }
        else{
            printf("\n%d. vnoreni - ZAPAD -> krok a nove zanoreni", cisloZanoreni);
            vypln(ZAPAD);
        }
    }
    else{
        printf("\n%d. vnoreni - ZAPAD -> zed.", cisloZanoreni);
    }
}

/**
 * @brief Algoritmus prohledávání jížního směru aktuální pozice.
 * @param cisloZanoreni udává číslo následujícího volání funkce \b vypln.
 *
 * Karel pokud může udělá krok na jih. Pokud se na daném místě nenachází žádná značka zavolá se funkce \b vypln
 */
void naJih(int cisloZanoreni){
    while(!jeOtocenNaJih()){
        vlevoVbok();
    }
    if(!jePredemnouZed()){
        krok();
        if(jeZdeZnacka()){
            printf("\n%d. vnoreni - JIH -> krok -> vracim se zpet, zde uz jsme znacku polozil", cisloZanoreni);
            krokZpet();
        }
        else{
            printf("\n%d. vnoreni - JIH -> krok a nove zanoreni", cisloZanoreni);
            vypln(JIH);
        }
    }
    else{
        printf("\n%d. vnoreni - JIH -> zed.", cisloZanoreni);
    }
}

/**
 * @brief Karel se otočí o 180° a udělá krok zpět.
 */
void krokZpet(){
    vlevoVbok();
    vlevoVbok();
    krok();
}

/**
 * @brief Karel se udělá jeden krok zpět směrem \b danySmer.
 * @param danySmer směr kterým se má robot Karel vrátit.
 */
void vratitSeOdkudJsemZdePrisel(smer danySmer){
    switch(danySmer){
        case SEVER:
            while(!jeOtocenNaSever()){
                vlevoVbok();
            }
            krokZpet();
            break;
        case JIH:
            while(!jeOtocenNaJih()){
                vlevoVbok();
            }
            krokZpet();
            break;
        case VYCHOD:
            while(!jeOtocenNaVychod()){
                vlevoVbok();
            }
            krokZpet();
            break;
        case ZAPAD:
            while(!jeOtocenNaZapad()){
                vlevoVbok();
            }
            krokZpet();
            break;
        case NIKAM:
        default:
            break;
    }
}

//============ Funkce main ================================================================================================

/**
 * @brief Výchozí funkce programu.
 * @param argc představuje počet argumentů příkazové řádky.
 * @param argv je pole ukazatelů na argumenty příkazové řádky.
 * @return Návratová hodnota 0 značí úspěšné ukončení programu.
 */
int main(int argc, char **argv)
{
    postavitMesto("Mesto-ZaplavovyAlgoritmus.txt");

    vypln(NIKAM);
    printf("\n\nVsechno vim, vsechno znam, vsude jsem byl! Karel");

    zbouratMesto();
    return 0;
}