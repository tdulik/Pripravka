#include <stdbool.h>

/*
 * @brief Uzivatelska funkce, ktera se stara o inicializaci knihovny Robota Karla.
 * @param nazevMapyMesta Cesta k souboru mapy mesta s priponou txt.
 * @return Vraci hodnotu true pokud nenastala zadna chyba.
 *
 * V pripade vyskytu chyby pri inicializaci je program ukoncen.
 * Funkce zastresuje samotnou inicializaci knihovny, vytvoreni a vykresleni pocatecniho obrazu do vytvoreneho okna programoveho rozhrani.
 */
bool postavitMesto(char *nazevMapyMesta);

/*
 * @brief Uzivatelska funkce, ktera spravne ukonci programove rozhrani knihovny Robota Karla.
 */
void zbouratMesto();


//Zakladni prikazy, ktere karel ovlada:
/*
 * @brief Karel udela 1 krok ve smeru ve kterem je natocen.
 * @return NUdelal-li robot Karel krok spravne je navratova hodnota true, jinak je navratova hodnota false.
 */
bool krok();

/*
 * @brief Robot Karla se otoci vlevo, tj. o 90 stupnu proti smeru hodninovych rucicek.
 * @return Hodnota true je vracena po spravnem natoceni robota. Jinak je vracena hodnota false.
 */
bool vlevoVbok();

/*
 * @brief Robot Karel zvedne jednu znacku z mista, na kerem se nachazi.
 * @return Hodnota true je vracena pri uspesnem zvednuti znacky.
 * Hodnota false je vracena, pokusi-li se Karel zvednout znacku, ktera na danem miste neni, nebo nastane-li chyba pri renderovani.
 */
bool zvedniZnacku();

/*
 * @brief Robot Karel polozi jednu znacku na misto na kterem stoji.
 * @return Hodnota true je vracena pri uspesnem polozeni znacky.
 * Hodnota false je vracena polozi-li robot Karel na danem miste vice jak 6 znacek, nebo pri neuspesnem renderovani textury.
 */
bool polozZnacku();

//Zakladni podminky, ktere karel vyhodnoti:
/*
 * @brief Karel zjisti zda se pred nim nachazi zed.
 * @return Pri detekci zdi je vracena hodnota true, jinak hodnota false.
 */
bool jePredemnouZed();

/*
 * @brief Karel zjisti zda se vlevo od nej nachazi zed.
 * @return Pri detekni zdi je vracena hodnota true, jinak hodnota false.
 */
bool jeVlevoZed();

/*
 * @brief Karel zjisti zda se vpravo od nej nachazi zed.
 * @return Pri detekni zdi je vracena hodnota true, jinak hodnota false.
 */
bool jeVpravoZed();

/*
 * @brief Robot Karel zjisti zda se na miste na kterem stoji nachazi znacka.
 * @return Pri detekni znacky je vracena hodnota true, jinak hodnota false.
 */
bool jeZdeZnacka();

/*
 * @brief Robot Karel zjisti zda se na miste na kterem stoji nachazi domecek.
 * @return Pri detekni domecku je vracena hodnota true, jinak hodnota false.
 */
bool jeZdeDomecek();

/*
 * @brief Robot Karel zjisti zda je natocen na sever.
 * @return Je-li Karel natocen na sever, je navratova hodnota true. Jinak je navratova hodnota false.
 */
bool jeOtocenNaSever();

/*
 * @brief Robot Karel zjisti zda je natocen na jih.
 * @return Je-li Karel natocen na jih, je navratova hodnota true. Jinak je navratova hodnota false.
 */
bool jeOtocenNaJih();

/*
 * @brief Robot Karel zjisti zda je natocen na vychod.
 * @return Je-li Karel natocen na vychod, je navratova hodnota true. Jinak je navratova hodnota false.
 */
bool jeOtocenNaVychod();

/*
 * @brief Robot Karel zjisti zda je natocen na zapad.
 * @return Je-li Karel natocen na zapad, je navratova hodnota true. Jinak je navratova hodnota false.
 */
bool jeOtocenNaZapad();

/*
 * @brief Robot Karel zjisti pocet znacek, nachazejicich se na miste, na kterem aktualne stoji.
 * @return Navratovou hodnotou je cele cislo oznacujici pocet znacek.
 */
int pocetZnacek();