/**
 * @mainpage  Dokumentace knihovny Robota Karla
 *
 * Tato dokumentace Vám poskytne věcné informace o Knihovně robota Karla.
 * Dokumentace pojednává o následujících souborech:
 *  -# zdrojový soubor  KnihovnaRobotaKarla.c
 *  -# hlavičkový soubor  KnihovnaRobotaKarla.h
 *
 * Programové rozhraní Knohovny robota Karla je vytvořeno pomocí funkcí knihovny SDL. Podrobné informace o této knihovně
 * naleznete na <a href="https://www.libsdl.org/">oficiálních stránkách knihovny</a>.
 *
 * Při vytváření Knihovny robota Karla byla požit knihovna SDL2 ve verzi 2.0.4. Dokumentaci ke knihovně SDL2 naleznete <a href="https://wiki.libsdl.org/">zde</a>.
 *
 *
 * Knihovna robota Karla vznikla jako součást bakalářské práce studenta <b>Tomáše Leciána</b> na <b>Univerzitě Tomáše Bati</b> ve Zlíně v roce 2017.
 */

#include <SDL.h>
#include <stdio.h>
#include <stdbool.h>
#include <time.h>
#ifdef _WIN32
    #include <windows.h>
#else
    #define _POSIX_C_SOURCE 199309L
    #include <math.h>
#endif


const int SIZE_OF_THE_PLAY_POINT = 40; /**<Definuje velikost polí sítě města v pixelech.*/
const int START_POINT_X = 0; /**<Definuje hodnotu \b x souřadnicového systému, pro vykreslování obrazu okna rozhraní.*/
const int START_POINT_Y = 0; /**<Definuje hodnotu \b y souřadnicového systému, pro vykreslování obrazu okna rozhraní.*/

/**
 *@brief \b TexturesOfKarelAndMap označuje jednotlivé textury využívané v programovém rozhraní.
 *@warning Pořadí textur musí být zachováno. Při jeho změně je nutno ve funkcích <b>changeSpeedMinus()</b> a <b>changeStatus()</b>
 * změnit hodnoty součtů definující správnou texturu ovládajícího panelu!
 */
enum TexturesOfKarelAndMap{
    TEXTURE_KAREL_UP, /**<Textura reprezentující robota Karla otočeného na sever.*/
    TEXTURE_KAREL_DOWN, /**<Textura reprezentující robota Karla otočeného na jih.*/
    TEXTURE_KAREL_LEFT, /**<Textura reprezentující robota Karla otočeného na západ.*/
    TEXTURE_KAREL_RIGHT, /**<Textura reprezentující robota Karla otočeného na východ.*/
    TEXTURE_WALL, /**<Textura reprezentující zeď města.*/
    TEXTURE_HOUSE, /**<Textura reprezentující Karlův domeček.*/
    TEXTURE_MARK1, /**<Textura reprezentující 1 položenou značku.*/
    TEXTURE_MARK2, /**<Textura reprezentující 2 položenou značku.*/
    TEXTURE_MARK3, /**<Textura reprezentující 3 položenou značku.*/
    TEXTURE_MARK4, /**<Textura reprezentující 4 položenou značku.*/
    TEXTURE_MARK5, /**<Textura reprezentující 5 položenou značku.*/
    TEXTURE_MARK6, /**<Textura reprezentující 6 položenou značku.*/
    TEXTURE_SPEED_PANEL_PLAY, /**<Textura reprezentující panel Rychlosti vykonávaných příkazů v režimu PAUSE.*/
    TEXTURE_SPEED_PANEL_PAUSE, /**<Textura reprezentující panel Rychlosti vykonávaných příkazů v režimu PLAY.*/
    TEXTURE_TOTAL /**<Hodnota udáva celkový počet používaných textur.*/
};

/**
 *@brief Prvky výčtového typu charakterizují význam místa ve městě.
 */
typedef enum {
	WALL, /**<Označení, že se na daném místě ve městě nachází zeď.*/
    HOUSE, /**<Označení, že se na daném místě ve městě nachází domeček.*/
    MARK1, /**<Označení, že se na daném místě ve městě nachází 1 značka.*/
    MARK2, /**<Označení, že se na daném místě ve městě nachází 2 značka.*/
    MARK3, /**<Označení, že se na daném místě ve městě nachází 3 značka.*/
    MARK4, /**<Označení, že se na daném místě ve městě nachází 4 značka.*/
    MARK5, /**<Označení, že se na daném místě ve městě nachází 5 značka.*/
    MARK6, /**<Označení, že se na daném místě ve městě nachází 6 značka.*/
    SPACE, /**<Označení, že se na daném místě ve městě se nic nenachází.*/
    TOTAL /**<Hodnota označuje celkový počet možných označení.*/
} significanceOfThePlayPoint;

/**
 *@brief Charakterizuje směr, kterým může být robot Karel natočen.
 */
typedef enum {
	UP, /**<Robot Karel je otočen na sever.*/
    LEFT, /**<Robot Karel je otočen na západ.*/
    DOWN, /**<Robot Karel je otočen na jih.*/
    RIGHT /**<Robot Karel je otočen na východ.*/
} direction;

/**
 *@brief Definuje režim (status) v jakém se nachází programové rozhraní robota Karla.
 */
typedef enum {
    PAUSE, /**<Programové rozhraní je v režimu pozastaveno.*/
    PLAY, /**<Programové rozhraní je v režimu spuštěno.*/
    NOT_INIT /**<Programové rozhraní není inicializováno.*/
} status;

/**
 *@brief Struktura \b karelProperties definuje vlastnosti robota Karla, pomocí kterých je jej možno ovládat.
 */
struct karelProperties{
    int rowMatrix; /**<Index řádku matice, na kterém se Karel aktuálně nachází.*/
    int columnMatrix; /**<Index sloupce matice, ve kterém se Karel aktuálně nachází.*/
    SDL_Texture *texture; /**<Textura kterou je Karel vykreslován.*/
    SDL_Rect *positionRectangle; /**<Struktura definující umístění textury Karla.*/
    direction karelsDirection; /**<Směr kterým je robot Karel natočen.*/
    int houseRow; /**<Index řádku matice, na kterém je umístěn Karlův domeček.*/
    int houseColumn; /**<Index sloupce matice, ve kterém je umístěn Karlův domeček.*/
    int speedLevel; /**<Stupeň rychlosti, jakým robot Karel vykovává příkazy.*/
    float speed; /**<Minimální počet taktů procesoru potřebných pro splnění stupně rychlosti vykonávání příkazů.*/
}gKarel; /**<Představuje samotného robota Karla, kterého uživatel ovládá.*/

SDL_Window *gWindow = NULL; /**<Reprezentuje okno programového rozhraní.*/
SDL_Renderer *gRenderer = NULL; /**<Je render zprostředkovávající vykresleí obrazu do okna programového rozhraní.*/
SDL_Texture *gTexturesOfKarelAndMap[TEXTURE_TOTAL]; /**<Pole s texturami, které jsou použity v programovém rozhraní.*/
int gPlayGroundWidht = 0; /**<Uchovává informaci o počtu polí na šířku města.*/
int gPlayGroundHeight = 0; /**<Uchovává informaci o počtu polí na výšku města.*/
int **gSemanticMatrix = NULL;  /**<Je dvourozměrné pole (matice), které v programu představuje samotné město.*/
status gStatus = NOT_INIT; /**<Uchovává informaci o stavu inicializace města.*/
int gErrorsKarel = 0; /**<Udává počet chyb, které vznikly nesprávným použitím uživatelských funkcí.*/
int gErrorsInternal = 0; /**<Udává počet chyb , které vznikly nesprávným vykreslením či neúspěsnou alokací paměti.*/
char gTimeFormat[13]; /**<Pole znaků reprezentující časový formát.*/



//============================================================= Function declarations ================================================================================

//Users functions:
bool postavitMesto(char *nazevMapyMesta);
void zbouratMesto();
bool krok();
bool vlevoVbok();
bool zvedniZnacku();
bool polozZnacku();
bool jePredemnouZed();
bool jeVlevoZed();
bool jeVpravoZed();
bool jeZdeZnacka();
bool jeZdeDomecek();
bool jeOtocenNaSever();
bool jeOtocenNaJih();
bool jeOtocenNaVychod();
bool jeOtocenNaZapad();
int pocetZnacek();

//Internal function:
bool init(char *nameOfTheMap);
bool creationOfTheEntireTown();
void close();
bool determineTheSizeOfThePlayground(char *nameOfMap, int *gPlayGroundWidht, int *gPlayGroundHeight);
bool verificationTheMapSize(int readWidth, int readHeight);
bool creatingWindow();
bool loadingTexturesAndCreatingFavicon();
bool initKarel(bool karlPositionIsDefined);
int **createSemanticMatrix(int *gPlayGroundWidht, int *gPlayGroundHeight);
bool fillSemanticMatrixAndInitKarel(char *nameOfMap, int **semanticMatrix, int *rows, int *column);
bool createPlayGround(int widhtOfPlayGround, int heightOfPlayGround);
bool fillPlayground(int **semanticMatrix);
bool createToolBar(int rows, int textureOfSpeedPanel);
bool changeSpeed(int rows, int levelOfSepeed);
void checkEvents();
void changeSpeedMinus();
void changeSpeedPlus();
void changeStatus();
void checkingInitialization();
void myDelay(int clockTicks);
bool crossingTheBorder(int newX, int newY, int widhtPlayGround, int heightPlayGround);
SDL_Texture *returnTextureOfMap(significanceOfThePlayPoint playPoint);
SDL_Texture *returnTextureOfKarel(direction newDirectionOfKarel);
bool renderingThePastPositions();
bool newKarelPosition(int changeX, int changeY);
bool refreshCurrentPosition();
bool isFrontBlocked(int changeX, int changeY);
bool determiningTheNewPositionInDirection(direction direct, bool (*function)());
char *getTime();


//===================================================================== Function =======================================================================================

/**
 * @brief Uživatelská funkce, která se stará o inicializaci knihovny.
 * @param nameOfTheMap Cesta k souboru mapy města s příponou txt.
 * @return Vrací hodnotu \b true pokud nenastala žádná chyba.
 * @warning V případě výskytu chyby při inicializaci je program ukončen.
 *
 * Funkce zastřešuje samotnou inicializaci knihovny, vytvoření a vykreslení obrazu do nově vytvořeného okna programového rozhraní.
 */
bool postavitMesto(char *nameOfTheMap){
    if(init(nameOfTheMap) == true){
        if(creationOfTheEntireTown() == true){
            gStatus = PAUSE;
            while(gStatus != PLAY){
                checkEvents();
                SDL_Delay(100);
            }
            return true;
        }
    }
    close();
    fprintf(stderr, "\n\n==============================");
    fprintf(stderr, "\nKarlovy nezdary: %d\nInterni chyby: %d", gErrorsKarel, gErrorsInternal);
    printf("\n\nPro ukonceni stisknete klavasu ENTER");
    getchar();
    exit(1);
}

/**
 * @brief Uživatelská funkce, která správně ukončí programové rozhraní.
 */
void zbouratMesto(){
    myDelay(1500);
    close();
    fprintf(stderr, "\n\n==============================");
    fprintf(stderr, "\nKarlovy nezdary: %d\nInterni chyby: %d", gErrorsKarel, gErrorsInternal);
    printf("\n\nPro ukonceni stisknete klavesu ENTER");
    getchar();
}

/**
 * @brief Uživatelská funkce pomocí které robot Karel udělá krok vpřed, ve směru ve kterém jen natočen.
 * @return Návratovou hodnotou je \b true udělal-li robot Karel krok správně. \b False je vrácono nastala-li v průběhu nějaká chyba.
 */
bool krok(){
    checkingInitialization();
    myDelay(gKarel.speed);
    return determiningTheNewPositionInDirection(gKarel.karelsDirection, newKarelPosition);
}

/**
 * @brief Uživatelská funkce, robot Karla se otočí vlevo, tj. o 90° proti směru hodninových ručiček.
 * @return Hodnota \b true je vrácena nenastane-li žádná chyba, jinak je vrácena hodnota \b false.
 */
bool vlevoVbok(){
    checkingInitialization();
    myDelay(gKarel.speed);
    gKarel.karelsDirection++;
    if(gKarel.karelsDirection > 3){
        gKarel.karelsDirection = 0;
    }
    gKarel.texture = returnTextureOfKarel(gKarel.karelsDirection);
    return refreshCurrentPosition();
}

/**
 * @brief Uživatelská funkce, Karel zvedne jednu značku z místa, na kerém se nachází.
 * @return Hodnota \b false je vrácena pokusí-li se Karel zvednout značku, která na daném místě není, nebo při nesprávném vykreslení.
 * Hodnota \b true je vrácena při úspěšném zvednutí značky.
 */
bool zvedniZnacku(){
    checkingInitialization();
    myDelay(gKarel.speed);
    if((gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] < MARK1) || (gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] > MARK6)){
        fprintf(stderr, "\n%s - Karel nemuze zvednout znacku. Zadna zde neni.", getTime());
        gErrorsKarel++;
        return false;
    }
    else{
        if(gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] == MARK1){
            gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] = SPACE;
        }
        else{
            gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix]--;
        }
        return refreshCurrentPosition();
    }
}

/**
 * @brief Uživatelská funkce, Karel položí jednu značku na místě na kterém stojí.
 * @return Hodnota \b false je vrácena položí-li Karel více než 6 značek na daném místě nebo při nesprávném vykreslení. Jinak je vrácena hodnota \b true.
 */
bool polozZnacku(){
    checkingInitialization();
    myDelay(gKarel.speed);
    if(gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] == MARK6){
        fprintf(stderr, "\n%s - Karel nemuze polozit vice nez 6 znacek na sebe.", getTime());
        gErrorsKarel++;
        return false;
    }
    else{
        if((gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] == SPACE) || (gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] == HOUSE)){
            gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] = MARK1;
        }
        else{
            gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix]++;
        }
        return refreshCurrentPosition();
    }
}

/**
 * @brief Uživatelská funkce vyhodnocující zda se před robotem Karlem nachází zeď.
 * @return Při detekci zdi je vrácena hodnota \b true, jinak hodnota \b false.
 */
bool jePredemnouZed(){
    checkingInitialization();
    return determiningTheNewPositionInDirection(gKarel.karelsDirection, isFrontBlocked);
}

/**
 * @brief Uživatelská funkce zjišťující, zda se nachází zeď po levé straně robota Karla.
 * @return Při detekni zdi je vrácena hodnota \b true, jinak hodnota \b false.
 */
bool jeVlevoZed(){
    checkingInitialization();
    direction tenpDirection = gKarel.karelsDirection + 1;
    if(tenpDirection > 3){
        tenpDirection = 0;
    }
    return determiningTheNewPositionInDirection(tenpDirection, isFrontBlocked);
}

/**
 * @brief Uživatelská funkce zjišťující, zda se nachází zeď po pravé straně robota Karla.
 * @return Při detekni zdi je vrácena hodnota \b true, jinak \b false.
 */
bool jeVpravoZed(){
    checkingInitialization();
    direction tenpDirection = gKarel.karelsDirection - 1;
    if(tenpDirection > 3){ //Data type direction is non-significant . So the result of the expression 0-1 is a large positive number and not be negative number.
        tenpDirection = 3;
    }
    return determiningTheNewPositionInDirection(tenpDirection, isFrontBlocked);
}

/**
 * @brief Uživatelská funkce zjišťující, zda se na místě na kterém robot Karel aktuálně stojí nachází nějaká značka.
 * @return V případě dedekce značky je vrácena hodnota \b true, jinak hodnota \b false.
 */
bool jeZdeZnacka(){
    checkingInitialization();
    if((gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] < MARK1) || (gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] > MARK6)){
        return false;
    }
    return true;
}

/**
 * @brief Uživatelská funkce zjišťující, zda se na místě na kterém robot Karel aktuálně stojí, nachází domeček.
 * @return V případě dedekce domečku je vrácena hodnota \b true, jinak hodnota \b false.
 */
bool jeZdeDomecek(){
    checkingInitialization();
    if(gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix] == HOUSE){
        return true;
    }
    return false;
}

/**
 * @brief Uživatelská funkce zjišťující zda je robot Karel otočen na sever.
 * @return Je-li karel otočen na sever je návratová hodnota \b true, jinak je návratová hodnota \b false.
 */
bool jeOtocenNaSever(){
    checkingInitialization();
    if(gKarel.karelsDirection == UP){
        return true;
    }
    return false;
}

/**
 * @brief Uživatelská funkce zjišťující zda je robot Karel otočen na jih.
 * @return Je-li Karel otočen na jih je návratová hodnota \b true, jinak je návratohá hodnota \b false.
 */
bool jeOtocenNaJih(){
    checkingInitialization();
    if(gKarel.karelsDirection == DOWN){
        return true;
    }
    return false;
}

/**
 * @brief Uživatelská funkce zjišťující zda je robot Karel otočen na východ.
 * @return Je-li karel otočen na východ je návratová hodnota \b true, jinak je návratohá hodnota \b false.
 */
bool jeOtocenNaVychod(){
    checkingInitialization();
    if(gKarel.karelsDirection == RIGHT){
        return true;
    }
    return false;
}

/**
 * @brief Uživatelská funkce zjišťující zda je robot Karel otočen na západ.
 * @return Je-li karel otočen na západ je návratová hodnota \b true, jinak je návratohá hodnota \b false.
 */
bool jeOtocenNaZapad(){
    checkingInitialization();
    if(gKarel.karelsDirection == LEFT){
        return true;
    }
    return false;
}

/**
 * @brief Uživatelská funkce zjišťující, počet značek nacházejících se na místě, na kterém robot Karel aktuálně stojí.
 * @return Návratová hodnota je celé číslo označující počet značek.
 */
int pocetZnacek(){
    checkingInitialization();
    switch(gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix]){
        case MARK1:
            return 1;
            break;
        case MARK2:
            return 2;
            break;
        case MARK3:
            return 3;
            break;
        case MARK4:
            return 4;
            break;
        case MARK5:
            return 5;
            break;
        case MARK6:
            return 6;
            break;
        default:
            return 0;
            break;
    }
}


/**
 * @brief Funkce init() inicializuje knihovnu a vytvoří okno programového rozhraní.
 * @param nameOfTheMap Cesta k souboru TXT představující mapu města.
 * @return Po úspěšné inicializace je vrácena hodnota \b true, jinak hodnota \b false.
 *
 * Funkce inicializuje subsystémy, které budou využívány knihovnou SDL2. Z mapy města se zjistí velikost města, tj. počet polí na šířku a výšku města.
 * Vytvoří se okno programového rozhraní a render, který bude zprostředkovávat vykreslení obrazu do tohoto okna. Z adresáře \b Textury se načtou textury
 * potřebné pro vykreslení obrazu rozhraní. Vytvoří se matice, která bude reprezentovat město a vyplní se objekty, které se ve městě nachází.
 */
bool init(char *nameOfTheMap){
    //Initialization the SDL video:
    if(SDL_Init(SDL_INIT_VIDEO) < 0){
        fprintf(stderr, "\n%s - Nespravne inicializovane subsystemy, ktere knihovna SDL vyuziva. SDL_Error: %s", getTime(), SDL_GetError() );
        gErrorsInternal++;
        return false;
    }
    //Determining the width and height of the playground:
    if(determineTheSizeOfThePlayground(nameOfTheMap, &gPlayGroundHeight, &gPlayGroundWidht) == false){
        return false;
    }
    //Creating the window:
    if(creatingWindow() == false){
        return false;
    }
    //Creating the renderer:
    gRenderer = SDL_CreateRenderer(gWindow, -1, 0);
    if(gRenderer == NULL){
        fprintf(stderr, "\n%s - Chyba pri vytvareni renderu. SDL Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    //Loading the textures and creating the favicon:
    if(loadingTexturesAndCreatingFavicon() == false){
        return false;
    }
    //Creating the semantic matrix from count of the rows and column:
    gSemanticMatrix = createSemanticMatrix(&gPlayGroundHeight, &gPlayGroundWidht);
    if(gSemanticMatrix == NULL){
        fprintf(stderr, "\n%s - Neuplne vytvoreni Vyznamove matice (dvojrozmerneho pole) slozici pro ulozeni mesta v programu.", getTime());
        gErrorsInternal++;
        return false;
    }
    //Filling the the Semantic matrix values from the TXT file and initialization properties of Karel:
    if(fillSemanticMatrixAndInitKarel(nameOfTheMap, &(*gSemanticMatrix), &gPlayGroundHeight, &gPlayGroundWidht) == false){
        return false;
    }
    return true;
}

/**
 * @brief Vytvoří obraz a vykreslí jej do okna programového rozhraní.
 * @return Po správném vytvoření a vykreslení obrazu je návratová hodnota \b true, jinak \b false.
 *
 * Funkce creationOfTheEntireTown() vytvoří pozadí celého města. Na jednotlivá místa vykreslí objekty města, tak jak jsou uvedené v \b gSemanticMatrix.
 * Robot Karel se vykreslí na místě, na kterém je definovaný v mapě města. Vykreslí se ovládací panel pro změnu rychlosti a celý obraz se render
 * zprostředkuje do okna programového rozhraní.
 */
bool creationOfTheEntireTown(){
    //Creating background of the playground:
    if(createPlayGround(gPlayGroundWidht, gPlayGroundHeight) == false){
         fprintf(stderr, "\n%s - Chyba pri rendrovani pozadi mesta. SDL_Error: %s", getTime(), SDL_GetError());
         gErrorsInternal++;
        return false;
    }
    //Filling the playground from the Semantic matrix:
    if(fillPlayground(gSemanticMatrix) == false){
        return false;
    }
    //Renrering of Karel:
    if(SDL_RenderCopy(gRenderer, gKarel.texture, 0, gKarel.positionRectangle) < 0){
        fprintf(stderr, "\n%s - Chyba pri rendrovani pocatecni pozice robota Karla. SDL_Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    SDL_RenderPresent(gRenderer);
    //Rendering the Speed panel:
    if(createToolBar(gPlayGroundHeight, TEXTURE_SPEED_PANEL_PLAY) == false){
        return false;
    }
    return true;
}

/**
 * @brief Uvolní veškerou paměť, která byla Knihovnou robota Karla alokována.
 */
void close(){
    SDL_DestroyWindow(gWindow);
    gWindow = NULL;
    SDL_DestroyRenderer(gRenderer);
    gRenderer = NULL;
    SDL_Quit();
    //Destroying textures:
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_KAREL_UP]);
    gTexturesOfKarelAndMap[TEXTURE_KAREL_UP] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_KAREL_DOWN]);
    gTexturesOfKarelAndMap[TEXTURE_KAREL_DOWN] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_KAREL_LEFT]);
    gTexturesOfKarelAndMap[TEXTURE_KAREL_LEFT] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_KAREL_RIGHT]);
    gTexturesOfKarelAndMap[TEXTURE_KAREL_RIGHT] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_WALL]);
    gTexturesOfKarelAndMap[TEXTURE_WALL] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_HOUSE]);
    gTexturesOfKarelAndMap[TEXTURE_HOUSE] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_MARK1]);
    gTexturesOfKarelAndMap[TEXTURE_MARK1] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_MARK2]);
    gTexturesOfKarelAndMap[TEXTURE_MARK2] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_MARK3]);
    gTexturesOfKarelAndMap[TEXTURE_MARK3] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_MARK4]);
    gTexturesOfKarelAndMap[TEXTURE_MARK4] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_MARK5]);
    gTexturesOfKarelAndMap[TEXTURE_MARK5] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_SPEED_PANEL_PLAY]);
    gTexturesOfKarelAndMap[TEXTURE_SPEED_PANEL_PLAY] = NULL;
    SDL_DestroyTexture(gTexturesOfKarelAndMap[TEXTURE_SPEED_PANEL_PAUSE]);
    gTexturesOfKarelAndMap[TEXTURE_SPEED_PANEL_PAUSE] = NULL;
    gKarel.texture = NULL;
    free(gKarel.positionRectangle);
    gKarel.positionRectangle = NULL;

    if(gSemanticMatrix != NULL){
        int i;
        for(i=0; i<gPlayGroundHeight; i++){
            free(gSemanticMatrix[i]);
        }
        free(&(*gSemanticMatrix));
    }
}

/**
 * @brief Určí ze souboru TXT mapy města počet polí na šířku a výšku města.
 * @param[in] fileName Cesta k souboru mapy města ze kterého se určuje velikost města.
 * @param[out] finalCountOfRows Proměnná, do které se uloží zjištěný počet polí města na výšku.
 * @param[out] finalCountOfColumn Proměnná, do které se uloží zjištěný počet polí města na šířku.
 * @return Po úspěšném určení velikosti je návratovou hodnotou \b true.
 * Hodnota \b false je vrácena, při neúspěšném otevření souboru, nebo nesprávné velikosti města.
 */
bool determineTheSizeOfThePlayground(char *fileName, int *finalCountOfRows, int *finalCountOfColumn){
    FILE *file;
    int tempRows = 0;
    int tempColumn = 0;
    char character;
    int counterInTheRow = 0;
    int border = 0;
    bool theEndOfTheMap = false;
    bool theEndOfTheRow = false;

    if ((file = fopen(fileName, "r+")) == NULL) {
        fprintf(stderr, "\n%s - Chyba pri otevreni souboru obsahujici mapu mesta: %s. Zkontrolujte cestu k tomuto souboru.", getTime(), fileName);
        gErrorsInternal++;
        return false;
    }

    while((theEndOfTheMap == false)){
        //The first row of file, determining the number of columns:
        if(tempRows == 0){
            while((character = getc(file)) != '\n'){
                if(character == 'X'){
                    tempColumn++;
                }
                else{
                    fprintf(stderr, "\n%s - Chyba v mape mesta. Neuplna horni hranice mesta. V 1. radku se nachazi jiny znak nez znak 'X' urcujici hranici mesta.", getTime());
                    gErrorsInternal++;
                    return false;
                }
            }
            tempColumn = tempColumn -2 ;
        }
        counterInTheRow = 0;
        border = 0;
        theEndOfTheRow = false;
        //Scanning each rows:
        while(((character = getc(file)) != '\n') && (character != EOF)){
            if(theEndOfTheRow == false){
                //First character:
                if(counterInTheRow == 0){
                    if(character != 'X'){
                        fprintf(stderr, "\n%s - Chyba v mape mesta. Prvni znak %d. radku neni znak 'X' oznacujici hranici mesta.", getTime(), tempRows + 2);
                        gErrorsInternal++;
                        return false;
                    }
                }
                //Other character in the row:
                else{
                    if(character == 'X'){
                        border++;
                    }
                    //Checking the end of the row:
                    if(counterInTheRow == (tempColumn + 1)){
                        if(border == (tempColumn + 1)){
                            theEndOfTheMap = true;
                            theEndOfTheRow = true;
                        }
                        else{
                            if(character != 'X'){
                                fprintf(stderr, "\n%s - Chyba v mape mesta. Radek %d neni spravne ukoncen znakem 'X', nebo nema stejny pocet znaku jako ostatni radky.", getTime(), tempRows + 2);
                                gErrorsInternal++;
                                return false;
                            }
                            if(border > 1){
                                fprintf(stderr, "\n%s - Chyba v mape mesta. Na radku %d se nachazi vice jak 2 znaky 'X', nebo mapa neni sprvne ukoncena po sobe jdoucimi znaky 'X'.", getTime(), tempRows + 2);
                                gErrorsInternal++;
                                return false;
                            }
                            theEndOfTheRow = true;
                        }
                    }
                }
                counterInTheRow++;
            }
            else{
                fprintf(stderr, "\n%s - Chyba v mape mesta. Na konci %d. radku se nachazi nepotrebny znak. Konec radku musi byt ukoncen znakem 'X' oznacujici hranici mesta.", getTime(), tempRows + 2);
                gErrorsInternal++;
                return false;
            }
        }
        if(theEndOfTheRow == false){
            fprintf(stderr, "\n%s - Chyba v mape mesta. Radek %d neni spravne ukoncen znakem 'X', nebo nema stejny pocet znaku jako ostatni radky.", getTime(), tempRows + 2);
            gErrorsInternal++;
            return false;
        }
        if(character == EOF && theEndOfTheMap == false){
            fprintf(stderr, "\n%s - Chyba v mape mesta. Mapa mesta neni spravne ukoncena radkem po sobe jdoucich znaku 'X'.", getTime());
            gErrorsInternal++;
            return false;
        }
        tempRows++;
        theEndOfTheRow = false;
    }
    *finalCountOfRows = tempRows - 1;
    *finalCountOfColumn = tempColumn;
    if(verificationTheMapSize(*finalCountOfColumn, *finalCountOfRows)){
        return true;
    }
    else{
        return false;
    }
}

/**
 * @brief Ověřuje zda zjištěná velikost města odpovídá daným kritériím.
 * @param readWidth Zjištěný počet polí města na šířku.
 * @param readHeight Zjištěný počet polí města na výšku.
 * @return Při odpovídající velikosti města je návratová hodnota \b true, jinak \b false.
 *
 * Velikost města musí být menší, než jaké je nastavené rozlišení monitoru na platformě Windovs, nebo rozlišení 1280x720 u ostatních operačních systémů.
 */
bool verificationTheMapSize(int readWidth, int readHeight){
    int displayResolutionHeight;
    int displayResolutionWidth;
    bool correctSize = true;
    //Determining resolution display:
    #ifdef _WIN32
        displayResolutionHeight = GetSystemMetrics(SM_CYSCREEN);
        displayResolutionWidth = GetSystemMetrics(SM_CXSCREEN);
    #else
        displayResolutionHeight = 720;
        displayResolutionWidth = 1280;
    #endif
    //When the map is too large:
    if(readHeight * SIZE_OF_THE_PLAY_POINT + readHeight + 1 > displayResolutionHeight - (3 * SIZE_OF_THE_PLAY_POINT + 3)){
        fprintf(stderr, "\n%s - Velikost mesta na vysku je prilis velka. Zmente velikost mesta.", getTime());
        gErrorsInternal++;
        correctSize = false;
    }
    if(readWidth * SIZE_OF_THE_PLAY_POINT + readWidth + 1 > displayResolutionWidth){
        fprintf(stderr, "\n%s - Velikost mesta na sirku je prilis velka. Zmente velikost mesta.", getTime());
        gErrorsInternal++;
        correctSize = false;
    }
    //When the map is too small:
    if(readHeight < 1){
        fprintf(stderr, "\n%s - Velikost mesta na vysku je 0. Zmente velikost mesta.", getTime());
        gErrorsInternal++;
        correctSize = false;
    }
    if(readWidth < 1){
        fprintf(stderr, "\n%s - Velikost mesta na sirku je 0. Zmente velikost mesta.", getTime());
        gErrorsInternal++;
        correctSize = false;
    }
    return correctSize;
}

/**
 * @brief Vytvoření okna programového rozhraní knihovny Robota Karla.
 * @return Návratovou hodnotou je \b true, je-li okno úspěšně vytvořeno. Jinak je vrácena hodnota \b false.
 */
bool creatingWindow(){
    int tempWidthScreen = (gPlayGroundWidht * SIZE_OF_THE_PLAY_POINT) + gPlayGroundWidht + 1 + START_POINT_X;
    if(tempWidthScreen < START_POINT_X + 291)
        tempWidthScreen = START_POINT_X + 291;
    int tempHeightScreen = (gPlayGroundHeight * SIZE_OF_THE_PLAY_POINT) + gPlayGroundHeight + 1 + 58 + START_POINT_Y;
    gWindow = SDL_CreateWindow("Robot Karel",
                                SDL_WINDOWPOS_CENTERED,
                                SDL_WINDOWPOS_CENTERED,
                                tempWidthScreen, tempHeightScreen,
                                SDL_WINDOW_SHOWN);
    if(gWindow == NULL){
        fprintf(stderr, "\n%s - Chyba pri vytvareni okna programoveho rozhrani knihovny. SDL_Error: %s", getTime(), SDL_GetError() );
        gErrorsInternal++;
        return false;
    }
    return true;

}

/**
 * @brief Funkce loadingTexturesAndCreatingFavicon() načte všechny potřebné textury z operačního systému a vytvoří ikonu okna programového rozhraní.
 * @return Hodnota \b true je vrácena při úspěšném načtení všech textur ze systému. Jinak je návratovou hotnotou \b false.
 *
 * Obrázky jsou nahrány z operačního systému do struktury SDL_Surface knihovny SDL. Následně jsou přetransformovány do struktury SDL_Texture.
 */
bool loadingTexturesAndCreatingFavicon(){
    bool successfulLoad = true;
    SDL_Surface *tempSurface = NULL;
    Uint32 whiteColor;
    //Karel UP
    tempSurface = SDL_LoadBMP("Textury\\KarelNahoru.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "KarelNahoru.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_KAREL_UP] = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_KAREL_UP] == NULL){
           fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "KarelNahoru.bmp", SDL_GetError() );
           gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Karel DOWN
    tempSurface = SDL_LoadBMP("Textury\\KarelDolu.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "KarelDolu.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_KAREL_DOWN] = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_KAREL_DOWN] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "KarelDolu.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        //Setting favicon:
        SDL_SetWindowIcon(gWindow, tempSurface);
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Karel LEFT
    tempSurface = SDL_LoadBMP("Textury\\KarelVlevo.bmp");
    if(tempSurface == NULL){
         fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "KarelVlevo.bmp", SDL_GetError() );
         gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_KAREL_LEFT] = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_KAREL_LEFT] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "KarelVlevo.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Karel RIGHT
    tempSurface = SDL_LoadBMP("Textury\\KarelVpravo.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "KarelVpravo.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_KAREL_RIGHT] = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_KAREL_RIGHT] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "KarelVpravo.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }

    //Wall
    tempSurface = SDL_LoadBMP("Textury\\Zed.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "Zed.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        gTexturesOfKarelAndMap[TEXTURE_WALL] = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_WALL] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "Zed.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //House
    tempSurface = SDL_LoadBMP("Textury\\Dum.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "Dum.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_HOUSE]  = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_HOUSE] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "Dum.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Mark1
    tempSurface = SDL_LoadBMP("Textury\\Znacka1.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "Znacka1.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_MARK1]  = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_MARK1] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "Znacka1.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Mark2
    tempSurface = SDL_LoadBMP("Textury\\Znacka2.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "Znacka2.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_MARK2]  = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_MARK2] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "Znacka2.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Mark3
    tempSurface = SDL_LoadBMP("Textury\\Znacka3.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "Znacka3.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_MARK3]  = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_MARK3] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "Znacka3.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Mark4
    tempSurface = SDL_LoadBMP("Textury\\Znacka4.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "Znacka4.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_MARK4]  = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_MARK4] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "Znacka4.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Mark5
    tempSurface = SDL_LoadBMP("Textury\\Znacka5.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "Znacka5.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_MARK5]  = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_MARK5] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "Znacka5.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Mark6
    tempSurface = SDL_LoadBMP("Textury\\Znacka6.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "Znacka6.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        whiteColor = SDL_MapRGB(tempSurface->format, 255, 255, 255);
        SDL_SetColorKey(tempSurface, SDL_ENABLE, whiteColor);
        gTexturesOfKarelAndMap[TEXTURE_MARK6]  = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_MARK6] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "Znacka6.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Speed panel_play:
    tempSurface = SDL_LoadBMP("Textury\\SpeedPanel_play.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "SpeedPanel_play.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        gTexturesOfKarelAndMap[TEXTURE_SPEED_PANEL_PLAY]  = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_SPEED_PANEL_PLAY] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "SpeedPanel_play.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    //Speed panel_pause:
    tempSurface = SDL_LoadBMP("Textury\\SpeedPanel_pause.bmp");
    if(tempSurface == NULL){
        fprintf(stderr, "\n%s - Chyba pri nacitani obrazku: %s. SDL Error: %s", getTime(), "SpeedPanel_pause.bmp", SDL_GetError() );
        gErrorsInternal++;
        successfulLoad = false;
    }
    else{
        gTexturesOfKarelAndMap[TEXTURE_SPEED_PANEL_PAUSE]  = SDL_CreateTextureFromSurface(gRenderer, tempSurface);
        if(gTexturesOfKarelAndMap[TEXTURE_SPEED_PANEL_PAUSE] == NULL){
            fprintf(stderr, "\n%s - Chyba pri vytvareni textury z obrazku: %s. SDL Error: %s", getTime(), "SpeedPanel_pause.bmp", SDL_GetError() );
            gErrorsInternal++;
            successfulLoad = false;
        }
        SDL_FreeSurface(tempSurface);
        tempSurface = NULL;
    }
    return successfulLoad;
}

/**
 * @brief Vytvoření dvojrozměrného pole (matice) reprezentující město.
 * @param rows Počet řádků matice.
 * @param column Počet sloupců matice.
 * @return Návratovou hodnotou je \b true při úspěšném vytvoření matice. Jinak je návratová hodnota \b false.
 */
int **createSemanticMatrix(int *rows, int *column){
    int **tempSemanticMatrix;
    int i;

    tempSemanticMatrix = (int **)malloc(*rows * sizeof(int *));
    if(tempSemanticMatrix == NULL){
        fprintf(stderr, "\n%s - Nedostatek mista pro alokaci pameti, pri vytvareni radku Vyznamove matice.", getTime());
        gErrorsInternal++;
        return NULL;
    }
    for(i=0; i<*rows; i++){
        tempSemanticMatrix[i] = (int *) malloc(*column * sizeof(significanceOfThePlayPoint));
        if(tempSemanticMatrix[i] == NULL){
            fprintf(stderr, "\n%s - Nedostatek mista pro alokaci pameti, pri vytvareni sloupcu %d. radku Vyznamove matice.", getTime(), i);
            gErrorsInternal++;
            return NULL;
        }
    }
    return(tempSemanticMatrix);
}

/**
 * @brief Matice je vyplněna hotnotami na základě vytvořeného města v souboru mapy města.
 * @param[in] fileName Cesta k souboru mapy města.
 * @param[out] playGroundMatrix Matice jež má být vyplněny.
 * @param[in] rows Počet polí města na výšku.
 * @param[in] column Počet polí města na šířku.
 * @return Návratovou hodnotou je \b true, byla-li matice úspěšně vyplněna objekty města definovanými v mapě města.
 * Hodnota \n false je vrácena, při neúspěšném otevření souboru, nebo nesprávného obsahu v mapě města.
 *
 * Jsou procházeny všechny znaky souboru \b fileName, které tvoří město. Význam těchto znaků je ukládán do matice. Je ověřováno zda v mapě města není
 * definováno vícero umístění robota Karla, nebo jeho domečku a zda je poloha Karla vůbec definovaná.
 */
bool fillSemanticMatrixAndInitKarel(char *fileName, int **playGroundMatrix, int *rows, int *column){
    FILE *file;
    int actualRow = 0;
    int actualColumn = 0;
    char character;
    bool karelIsDefined = false;
    bool houseIsDefined = false;
    bool duplicateHouse = false;
    bool duplicateKarel = false;

    if ((file = fopen(fileName, "r+")) == NULL) {
        fprintf(stderr, "\n%s - Chyba pri otevreni souboru obsahujici mapu mesta: %s. Zkontrolujte cestu k tomuto souboru.", getTime(), fileName);
        gErrorsInternal++;
        return false;
    }
    while((character = getc(file)) != EOF){
        if(character == '\n'){
            actualRow++;
        }
        if((actualRow != 0) && (actualRow < *rows+1)){
            if((character != 'X') && (character != '\n')){
                switch(character){
                    case ' ':
                        playGroundMatrix[actualRow-1][actualColumn] = SPACE;
                        break;
                    case '#':
                        playGroundMatrix[actualRow-1][actualColumn] = WALL;
                        break;
                    case 'h':
                    case 'H':
                        if(houseIsDefined == true){
                            if(duplicateHouse == false){
                                duplicateHouse = true;
                                fprintf(stderr, "\n%s - V mape mesta je uvedeno vice domecku nez jeden. Zredukujte pocet Karlovych domecku v mape mesta.", getTime());
                                gErrorsInternal++;
                            }
                            break;
                        }
                        houseIsDefined = true;
                        playGroundMatrix[actualRow-1][actualColumn] = HOUSE;
                        //Reason for the saving coordinates of the house to the structure karelProperties is allowing put the mark at the house.
                        gKarel.houseRow = actualRow-1;
                        gKarel.houseColumn = actualColumn;
                        break;
                    case 'k':
                    case 'K':
                        if(karelIsDefined == true){
                            if(duplicateKarel == false){
                                duplicateKarel = true;
                                fprintf(stderr, "\n%s - V mape mesta je robot Karel definovan na vice mistech. Definujte pouze jednu polohu Karla v mape mesta.", getTime());
                                gErrorsInternal++;
                            }
                            break;
                        }
                        karelIsDefined = true;
                        playGroundMatrix[actualRow-1][actualColumn] = SPACE;
                        gKarel.rowMatrix = actualRow-1;
                        gKarel.columnMatrix = actualColumn;
                        break;
                    case '1':
                        playGroundMatrix[actualRow-1][actualColumn] = MARK1;
                        break;
                    case '2':
                        playGroundMatrix[actualRow-1][actualColumn] = MARK2;
                        break;
                    case '3':
                        playGroundMatrix[actualRow-1][actualColumn] = MARK3;
                        break;
                    case '4':
                        playGroundMatrix[actualRow-1][actualColumn] = MARK4;
                        break;
                    case '5':
                        playGroundMatrix[actualRow-1][actualColumn] = MARK5;
                        break;
                    case '6':
                        playGroundMatrix[actualRow-1][actualColumn] = MARK6;
                        break;
                    default:
                        playGroundMatrix[actualRow-1][actualColumn] = SPACE;
                        break;
                }
                actualColumn++;
            }
            if(actualColumn == *column){
                actualColumn = 0;
            }
        }
    }
    if(fclose(file) == EOF){
        fprintf(stderr, "\n%s - Chyba pri uzavreni souboru obsahujici mapu mesta: %s. Soubor se nepodarilo uzavrit.", getTime(), fileName);
        gErrorsInternal++;
        return false;
    }
    if(duplicateHouse || duplicateKarel){
        return false;
    }
    if(houseIsDefined == true){
        return initKarel(karelIsDefined);
    }
    else{
        fprintf(stderr, "\n%s - V mape mesta neni definovane, kde ma Karel domecek. Urcete v mape mesta polohu Karlova domecku.", getTime());
        gErrorsInternal++;
        return false;
    }
}

/**
 * @brief Inicializuje vlastností robota Karla.
 * @param karlPositionIsDefined Označuje zda je v mapě města definovaná Karlova poloha (hodnota \b true), nebo je jeho startovní poloha v domečku.
 * @return Návratová hodnota \b true pokud inicializace proběhla správně. Jinak hodnota \b false.
 *
 * Nastavují se všechny prvky struktury \b karelProperties pro úspěšné fungování programového rozhraní.
 */
bool initKarel(bool karlPositionIsDefined){
    if(karlPositionIsDefined == false){
        gKarel.rowMatrix = gKarel.houseRow;
        gKarel.columnMatrix = gKarel.houseColumn;
    }
    gKarel.karelsDirection = DOWN;
    gKarel.texture = gTexturesOfKarelAndMap[TEXTURE_KAREL_DOWN];
    gKarel.speedLevel = 5;
    gKarel.speed = 450;
    if((gKarel.positionRectangle = (SDL_Rect *)malloc(sizeof(SDL_Rect))) == NULL){
        fprintf(stderr, "\n%s - Nedostatek mista pro alokaci pameti, pri inicializaci robota Karla.", getTime());
        gErrorsInternal++;
        return false;
    }
    else{
        gKarel.positionRectangle->h = SIZE_OF_THE_PLAY_POINT;
        gKarel.positionRectangle->w = SIZE_OF_THE_PLAY_POINT;
        gKarel.positionRectangle->x = START_POINT_X + 1 + ((gKarel.columnMatrix) * SIZE_OF_THE_PLAY_POINT) + gKarel.columnMatrix;
        gKarel.positionRectangle->y = START_POINT_Y + 1 + ((gKarel.rowMatrix) * SIZE_OF_THE_PLAY_POINT) + gKarel.rowMatrix;
    }
    return true;
}

/**
 * @brief Vytvoří obraz pozadí onka programového rozhraní a prázdné město.
 * @param widhtOfPlayGround Počet polí města na šířku.
 * @param heightOfPlayGround Počet polí města na výšku.
 * @return Při úspěšném vykreslení je návratová hodnota funkce \b true. Jinak \b false.
 * @warning Funkce vytvořený obraz nevykresluje pomocí renderu.
 */
bool createPlayGround(int widhtOfPlayGround, int heightOfPlayGround){
    SDL_Rect playGround;
    playGround.h = (SIZE_OF_THE_PLAY_POINT * heightOfPlayGround)+heightOfPlayGround-1;
    playGround.w = (SIZE_OF_THE_PLAY_POINT * widhtOfPlayGround)+widhtOfPlayGround-1;
    playGround.x = START_POINT_X+1;
    playGround.y = START_POINT_Y+1;
    //Setting the background color of the window:
    if(SDL_SetRenderDrawColor(gRenderer, 255, 255, 176, 255) < 0){
        return false;
    }
    if(SDL_RenderClear(gRenderer) < 0){
        return false;
    }
    //Setting the background color of the town:
    if(SDL_SetRenderDrawColor(gRenderer, 239, 228, 176, 255) < 0){
        return false;
    }
    if(SDL_RenderFillRect(gRenderer, &playGround) < 0){
        return false;
    }
    //Setting the color of the town net:
    if(SDL_SetRenderDrawColor(gRenderer, 195, 195, 195, 255) <0 ){
        return false;
    }
    int i;
    for(i=0; i<=heightOfPlayGround; i++)
    {
        if(SDL_RenderDrawLine(gRenderer,
                            START_POINT_X,
                            START_POINT_Y + ((SIZE_OF_THE_PLAY_POINT+1)*i),
                            START_POINT_X + (SIZE_OF_THE_PLAY_POINT*widhtOfPlayGround) + widhtOfPlayGround,
                            START_POINT_Y + ((SIZE_OF_THE_PLAY_POINT+1)*i)) <0){
                                return false;
                            }
    }
    for(i=0; i<=widhtOfPlayGround; i++)
    {
       if(SDL_RenderDrawLine(gRenderer,
                            START_POINT_X + ((SIZE_OF_THE_PLAY_POINT+1)*i),
                            START_POINT_Y,
                            START_POINT_X + ((SIZE_OF_THE_PLAY_POINT+1)*i),
                            START_POINT_Y + (SIZE_OF_THE_PLAY_POINT*heightOfPlayGround) + heightOfPlayGround) < 0){
                                return false;
                            }
    }
    return true;
}

/**
 * @brief Stávající obraz se překreslí texturami jejiž polohy a typy jsou dány hodnotami prvků matice.
 * @param semanticMatrix Matice, která definuje typy a rozmístění textur pro vykreslení.
 * @return Návratová hodnota \b true je při úspěšném vykreslení všech textur v matici. Jinak je vrácena hodnota \b false.
 * @warning Funkce nevykresluje texturu robota Karla.
 * @warning Funkce vytvořený obraz nevykresluje pomocí renderu.
 *
 * Postupně jsou procházeny všechny prvky matice a podle hodnot těchto prvků je na dané místo vykreslena odpovídající textura.
 */
bool fillPlayground(int **semanticMatrix){
    SDL_Rect *positionRectangle = (SDL_Rect *)malloc(sizeof(SDL_Rect));
    if(positionRectangle == NULL){
        fprintf(stderr, "\n%s - Nedostatek mista pro alokaci pameti, pri vytvoreni obdelniku slouzici pro urceni pozice jednotlivych prvku mesta.", getTime());
        gErrorsInternal++;
        return false;
    }
    else{
        positionRectangle->h = SIZE_OF_THE_PLAY_POINT;
        positionRectangle->w = SIZE_OF_THE_PLAY_POINT;
        positionRectangle->x = START_POINT_X+1;
        positionRectangle->y = START_POINT_Y + (SIZE_OF_THE_PLAY_POINT + 1);
    }
    int i,j;
    for(i=0; i< gPlayGroundHeight; i++){
        positionRectangle->y = START_POINT_Y + 1 + i*(SIZE_OF_THE_PLAY_POINT + 1);
        for(j=0; j<gPlayGroundWidht; j++){
            positionRectangle->x = START_POINT_X + 1 + j*(SIZE_OF_THE_PLAY_POINT + 1);
            switch(semanticMatrix[i][j]){
                case SPACE:
                    break;
                case WALL:
                    if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_WALL], 0, positionRectangle) < 0){
                        fprintf(stderr, "\n%s - Nastala chyba pri renderovani textury zdi. SDL_Error: %s", getTime(), SDL_GetError());
                        gErrorsInternal++;
                        return false;
                    }
                    break;
                case HOUSE:
                    if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_HOUSE], 0, positionRectangle) < 0){
                        fprintf(stderr, "\n%s - Nastala chyba pri rendrovani textury domecku. SDL_Error: %s", getTime(), SDL_GetError());
                        gErrorsInternal++;
                        return false;
                    }
                    break;
                case MARK1:
                    if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_MARK1], 0, positionRectangle) < 0){
                        fprintf(stderr, "\n%s - Nastala chyba pri rendrovani textury 1. značky SDL_Error: %s", getTime(), SDL_GetError());
                        gErrorsInternal++;
                        return false;
                    }
                    break;
                case MARK2:
                    if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_MARK2], 0, positionRectangle) < 0){
                        fprintf(stderr, "\n%s - Nastala chyba pri rendrovani textury 2. značky SDL_Error: %s", getTime(), SDL_GetError());
                        gErrorsInternal++;
                        return false;
                    }
                    break;
                case MARK3:
                    if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_MARK3], 0, positionRectangle) < 0){
                        fprintf(stderr, "\n%s - Nastala chyba pri rendrovani textury 3. značky SDL_Error: %s", getTime(), SDL_GetError());
                        gErrorsInternal++;
                        return false;
                    }
                    break;
                case MARK4:
                    if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_MARK4], 0, positionRectangle) < 0){
                        fprintf(stderr, "\n%s - Nastala chyba pri rendrovani textury 4. značky SDL_Error: %s", getTime(), SDL_GetError());
                        gErrorsInternal++;
                        return false;
                    }
                    break;
                case MARK5:
                    if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_MARK5], 0, positionRectangle) < 0){
                        fprintf(stderr, "\n%s - Nastala chyba pri rendrovani textury 5. značky SDL_Error: %s", getTime(), SDL_GetError());
                        gErrorsInternal++;
                        return false;
                    }
                    break;
                case MARK6:
                    if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_MARK6], 0, positionRectangle) < 0){
                        fprintf(stderr, "\n%s - Nastala chyba pri rendrovani textury 6. značky SDL_Error: %s", getTime(), SDL_GetError());
                        gErrorsInternal++;
                        return false;
                    }
                    break;
                default:
                    break;
            }
        }
    }
    return true;
    free(positionRectangle);
}

/**
 * @brief Vytoří a překreslí stávající obraz texturou ovládajícího panelu.
 * @param rows Počet polí na výšku města (textura ovládacího panelu se vykreslune pod město)
 * @param textureOfSpeedPanel Textura ovládajícího panelu, která se má vykreslit.
 * @return Návratová hodnota \b true při úspěšném vykreslení, jinak je návratová hodnota \b false.
 */
bool createToolBar(int rows, int textureOfSpeedPanel){
    SDL_Rect *positionRectangle = (SDL_Rect *)malloc(sizeof(SDL_Rect));
    if(positionRectangle == NULL){
       fprintf(stderr, "\n%s - Nedostatek mista pro alokaci pameti, pri vykresleni ovladaciho panelu.", getTime());
       gErrorsInternal++;
       return false;
    }
    positionRectangle->h = 58;
    positionRectangle->w = 291;
    positionRectangle->x = START_POINT_X;
    positionRectangle->y = START_POINT_Y + (rows * SIZE_OF_THE_PLAY_POINT) + (rows + 1);
    if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[textureOfSpeedPanel], 0, positionRectangle) < 0){
        fprintf(stderr, "\n%s - Nastala chyba pri renderovani ovladaciho panelu. SDL_Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    SDL_RenderPresent(gRenderer);
    if(changeSpeed(rows, gKarel.speedLevel) == false){
        return false;
    }
    free(positionRectangle);
    return true;
}

/**
 * @brief Překreslí ukazatel rychlosti vykonávání příkazů na panelu ovládání (počet obdélníků).
 * @param rows Počet polí města na výšku.
 * @param levelOfSepeed Hodnota stupně rychlosti, který se má vykreslit.
 * @return Návratová hodnota \b true je vrácena při úspěšném překreslení, jinak je vrácena hodnota \b false.
 * @warning Funkce pouze vykresluje jednotlivé stupně rychlosti (obdélníky). Nepřekresluje celou oblast. Při vykreslení menšího počtu stupňů rychlosti,
 * než je aktuálně vykreslen, se nejprve musí vykreslit textura ovládacího panelu, jinak nebudou vykreslené stupně rychlosti odpovídat reálné hodnotě.
 */
bool changeSpeed(int rows, int levelOfSepeed){
    SDL_Rect *positionRectangle = (SDL_Rect *)malloc(sizeof(SDL_Rect));
    if(positionRectangle == NULL){
       fprintf(stderr, "\n%s - Nedostatek mista pri alokaci pameti, pro vykresleni stupne rychlosti na ovladacim panelu.", getTime());
       gErrorsInternal++;
        return false;
    }
    positionRectangle->h = 30;
    positionRectangle->w = 14;
    positionRectangle->y = START_POINT_Y + (rows * SIZE_OF_THE_PLAY_POINT) + (rows + 1) + 21 + 1;
    if(SDL_SetRenderDrawColor(gRenderer, 5, 122, 9, 255) < 0){
        fprintf(stderr, "\n%s - Chyba pri nastaveni barvy, pro renderovani stupne rychlosti pohybu robota Karla na ovladacim panelu. SDL_Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    int i;
    for(i=0; i < levelOfSepeed; i++){
        positionRectangle->x = START_POINT_X + 39 + (i * 16);
        if(SDL_RenderFillRect(gRenderer, positionRectangle) < 0){
            fprintf(stderr, "\n%s - Chyba pri renderovani panelu rychlosti. SDL_Error: %s", getTime(), SDL_GetError());
            gErrorsInternal++;
            return false;
        }
    }
    SDL_RenderPresent(gRenderer);
    free(positionRectangle);
    return true;
}

/**
 * @brief Obsluha události programového rozhraní knihovny.
 * @warning Událost uzavření okna programového rozhraní ukončí celý program.
 *
 * Funkce checkEvents() se stará o následující události: zavření a minimalizace okna programovéjo rozhraní, kliknutím myši na tlačítka +, -, Play, nebo Pause,
 * stisknutí kláves Enter, Mezerník, Escape, Plus, nebo Mínus. Ostatní události jsou ignorovány.
 *
 */
void checkEvents(){
    SDL_Event event;
    while(SDL_PollEvent(&event) != 0){
        switch(event.type){
            case SDL_QUIT:
                close();
                exit(0);
                break;

            case SDL_MOUSEBUTTONDOWN:
                //Minus:
                if((event.button.x >= START_POINT_X + 6) && (event.button.x <= START_POINT_X + 36)){
                    if((event.button.y >= START_POINT_Y + (gPlayGroundHeight * SIZE_OF_THE_PLAY_POINT) + (gPlayGroundHeight + 1) + 21 + 1)
                        && (event.button.y <= START_POINT_Y + (gPlayGroundHeight * SIZE_OF_THE_PLAY_POINT) + (gPlayGroundHeight + 1) + 21 + 31)){
                        changeSpeedMinus();
                    }
                }
                //Plus:
                if((event.button.x >= START_POINT_X + 183 + 1) && (event.button.x <= START_POINT_X + 214)){
                    if((event.button.y >= START_POINT_Y + (gPlayGroundHeight * SIZE_OF_THE_PLAY_POINT) + (gPlayGroundHeight + 1) + 21 + 1)
                        && (event.button.y <= START_POINT_Y + (gPlayGroundHeight * SIZE_OF_THE_PLAY_POINT) + (gPlayGroundHeight + 1) + 21 + 31)){
                        changeSpeedPlus();
                    }
                }
                //Play/pause:
                if((event.button.x > START_POINT_X + 247 + 1) && (event.button.x < START_POINT_X + 279)){
                    if((event.button.y >= START_POINT_Y + (gPlayGroundHeight * SIZE_OF_THE_PLAY_POINT) + (gPlayGroundHeight + 1) + 21 + 1)
                        && (event.button.y <= START_POINT_Y + (gPlayGroundHeight * SIZE_OF_THE_PLAY_POINT) + (gPlayGroundHeight + 1) + 21 + 31)){
                            changeStatus();
                    }
                }
                break;

            case SDL_KEYDOWN:
                switch(event.key.keysym.sym){
                    case SDLK_RETURN:
                    case SDLK_KP_ENTER:
                    case SDLK_SPACE:
                        changeStatus();
                        break;

                    case SDLK_MINUS:
                    case SDLK_KP_MINUS:
                        changeSpeedMinus();
                        break;

                    case SDLK_PLUS:
                    case SDLK_KP_PLUS:
                        changeSpeedPlus();
                        break;

                    case SDLK_ESCAPE:
                        close(0);
                        exit(0);
                        break;

                    default:
                        break;
                }
                break;

            case SDL_WINDOWEVENT:
                switch(event.window.event){
                    //Prevention of creation Karel's ghosts while minimizing window of program interface:
                    case SDL_WINDOWEVENT_EXPOSED:
                        creationOfTheEntireTown();
                        break;
                    default:
                        break;
                }
                break;

            default:
                break;
        }
    }
}

/**
 * @brief Rychlost vykonávání příkazů se zmenší o jeden stupeň.
 */
void changeSpeedMinus(){
    if(gKarel.speed < 1470){
        //If is speed lower than maximum speed:
        if(gKarel.speed < 450){
            gKarel.speed += 112.25; //The constant 112.25 is added at the interval <1; 450)
        }
        else{
            gKarel.speed += 255; //The constant 225 is added at the interval (450; 1470>
        }
        gKarel.speedLevel--;
        createToolBar(gPlayGroundHeight, gStatus + 12);
    }
}

/**
 * @brief Rychlost vykonávání příkazů se zvýší o jeden stupeň.
 */
void changeSpeedPlus(){
    if(gKarel.speed > 1){
        if(gKarel.speed <= 450){
            gKarel.speed -= 112.25; //The constant 112.25 is subtracted at the interval <1; 450)
        }
        else{
            gKarel.speed -= 255; //The constant 225 is subtracted at the interval (450; 1470>
        }
        gKarel.speedLevel++;
        changeSpeed(gPlayGroundHeight, gKarel.speedLevel);
    }
}

/**
 * @brief Dojde ke změně režimu (status PLAY/PAUSE) programového rozhraní a k aktualizaci ovládacího panelu.
 */
void changeStatus(){
    if(gStatus == PLAY){
        gStatus = PAUSE;
        createToolBar(gPlayGroundHeight, gStatus + 12);
        /*Result of expression gStatus + 12 is number (the element of enumeration type TexturesOfKarelAndMap) of the texture, which should be rendered.
        The order of the elements PLAY (TEXTURE_SPEED_PANEL_PLAY) and PAUSE (TEXTURE_SPEED_PANEL_PAUSE) is different
        in each enumeration types (status, TexturesOfKarelAndMap).
        */
    }
    else{
        gStatus = PLAY;
        createToolBar(gPlayGroundHeight, gStatus + 12);
    }
}

/**
 * @brief Kontroluje se, zda uživatel inicializoval knihovnu.
 * @warning Při zjištění, že knihovna nebyla inicializována dojde k ukončení programu.
 */
void checkingInitialization(){
    if(gStatus == NOT_INIT){
        close(0);
        fprintf(stderr, "\n%s - Karel nema postavene sve mesto. Pouzijte funkci otevritMesto(<CESTA_K_SOUBORU>).", getTime());
        gErrorsKarel++;
        fprintf(stderr, "\n\n==============================");
        fprintf(stderr, "\nKarlovy nezdary: %d\nInterni chyby: %d", gErrorsKarel, gErrorsInternal);
        printf("\n\nPro ukonceni stisknete klavesu ENTER");
        getchar();
        exit(1);
    }
}

/**
 * @brief Vykonávání uživatelského programu je pozastaveno na dobu definovanou počtem taktů procesoru.
 * @param clockTicks Počet taktů procesoru, které udávají dobu po kterou má být uživatelský program pozastaven.
 * @warning Celková doba pozastavení uživatelského programu je vždy delší, než definuje parametr \b clockTicks!
 * Doba záleží na plánovači procesů, za jakou dobu po opětovném probuzení procesu mu přidělí výpočetní čas jádra procesoru.
 */
void myDelay(int clockTicks){
    clock_t time = clock() + clockTicks ;
    while((clock() < time) || (gStatus == PAUSE)){
        checkEvents();
        if(gKarel.speedLevel != 9){
            SDL_Delay(100);
        }
    }
}

/**
 * @brief Kontrojule zda se robot Karel nepokouší překročit hranice města.
 * @param newRow Pole města definované na výšku, na které se robot Karel chystá vstoupit.
 * @param newColumn Pole města definované na šířku, na které se robot Karel chystá vstoupit.
 * @param widhtPlayGround Počet polí města na šířku.
 * @param heightPlayGround Počet polí města na výšku.
 * @return Pokusí-li se robot Karel překročit hranice města, je návratová hodnota funkce \b false. Jinak je návratová hodnota \b true.
 */
bool crossingTheBorder(int newRow, int newColumn, int widhtPlayGround, int heightPlayGround){
    if((newRow < 0) || (newRow >= heightPlayGround) || (newColumn < 0) || (newColumn >= widhtPlayGround)){
        return true;
    }
    return false;
}

/**
 * @brief Na základě hodnoty prvku matice je vrácena odpovídající textura.
 * @param playPoint Hodnota prvku matice.
 * @return Návratovou hodnotou je pointer na požadovanou texturu.
 * @warning Není-li prvku matice přiřazena žádná textura je návratohou hodnotou \b NULL.
 */
SDL_Texture *returnTextureOfMap(significanceOfThePlayPoint playPoint){
   switch(playPoint){
        case SPACE:
            return NULL;
            break;
        case WALL:
            return gTexturesOfKarelAndMap[TEXTURE_WALL];
            break;
        case HOUSE:
            return gTexturesOfKarelAndMap[TEXTURE_HOUSE];
            break;
        case MARK1:
            return gTexturesOfKarelAndMap[TEXTURE_MARK1];
            break;
        case MARK2:
            return gTexturesOfKarelAndMap[TEXTURE_MARK2];
            break;
        case MARK3:
            return gTexturesOfKarelAndMap[TEXTURE_MARK3];
            break;
        case MARK4:
            return gTexturesOfKarelAndMap[TEXTURE_MARK4];
            break;
        case MARK5:
            return gTexturesOfKarelAndMap[TEXTURE_MARK5];
            break;
        case MARK6:
            return gTexturesOfKarelAndMap[TEXTURE_MARK6];
            break;
        default:
            return NULL;
            break;
    }
}

/**
 * @brief Na základě směru natočení robota Karla je vrácena odpovídající textura znázorňující robota Karla..
 * @param newDirectionOfKarel Směr definující požadovanou texturu.
 * @return Návratovou hodnotou je pointer na odpovídající texturu robota Karla.
 */
SDL_Texture *returnTextureOfKarel(direction newDirectionOfKarel){
    switch(newDirectionOfKarel){
        case UP:
            return gTexturesOfKarelAndMap[TEXTURE_KAREL_UP];
            break;
        case DOWN:
            return gTexturesOfKarelAndMap[TEXTURE_KAREL_DOWN];
            break;
        case LEFT:
            return gTexturesOfKarelAndMap[TEXTURE_KAREL_LEFT];
            break;
        case RIGHT:
            return gTexturesOfKarelAndMap[TEXTURE_KAREL_RIGHT];
            break;
        default:
            return gTexturesOfKarelAndMap[TEXTURE_KAREL_UP];
            break;
    }
}

/**
 * @brief Překreslení pozice, na které se robot Karel nacházel před provedením kroku.
 * @return Návratovou hodnotou je \b true pokud je pozice v okně programového rozhraní úspěšně překreslena. Jinak je návratovou hodnotou \b false.
 * @warning Nový obraz je vykreslen pomocí renderu.
 */
bool renderingThePastPositions(){
    if(SDL_SetRenderDrawColor(gRenderer, 239, 228, 176, 255) < 0){
        fprintf(stderr, "\n%s - Chyba pri nastaveni barvy, pro prekresleni predchoziho pole, kde se nachezel robot Karel. SDL Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    if(SDL_RenderFillRect(gRenderer, gKarel.positionRectangle) < 0){
        fprintf(stderr, "\n%s - Chyba pri renderovani ctverce, pro prekresleni predchoziho pole, kde se nachezel robot Karel. SDL Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    if((gKarel.rowMatrix == gKarel.houseRow) && (gKarel.columnMatrix == gKarel.houseColumn)){
        if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_HOUSE], 0, gKarel.positionRectangle) < 0){
            fprintf(stderr, "\n%s - Chyba pri renderovani domecku, pro prekresleni predchoziho pole, kde se nachezel robot Karel. SDL Error: %s", getTime(), SDL_GetError());
            gErrorsInternal++;
            return false;
        }
    }
    SDL_RenderCopy(gRenderer, returnTextureOfMap(gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix]), 0, gKarel.positionRectangle); //Missing treatment of rendering, because value NULL define space in the town.
    return true;
}

/**
 * @brief Překreslení nové pozice města v programovém rozhraní, na které se robot Karel přemístil.
 * @param changedX  Pole města definované na šířku, na které se robot Karel chystá vstoupit.
 * @param changedY Pole města definované na výšku, na které se robot Karel chystá vstoupit.
 * @return Návratovou hodnotou je \b true, dojde-li k úspěšnému překreslení nové pozice robota Karla. Jinak je návratovou hodnotou \b false.
 * @warning  Nový obraz je vykreslem pomocí renderu.
 */
bool newKarelPosition(int changedX, int changedY){
    if(crossingTheBorder(gKarel.rowMatrix + changedY, gKarel.columnMatrix + changedX, gPlayGroundWidht, gPlayGroundHeight)){
        fprintf(stderr, "\n%s - Karel narazil do hranicni zdi mesta.", getTime());
        gErrorsKarel++;
        return false;
    }
    if(gSemanticMatrix[gKarel.rowMatrix + changedY][gKarel.columnMatrix + changedX] == WALL){
        fprintf(stderr, "\n%s - Karel narazil do zdi.", getTime());
        gErrorsKarel++;
        return false;
    }
    if(!renderingThePastPositions()){
        return false;
    }
    gKarel.positionRectangle->x += changedX * (SIZE_OF_THE_PLAY_POINT + 1);
    gKarel.positionRectangle->y += changedY * (SIZE_OF_THE_PLAY_POINT + 1);
    gKarel.columnMatrix += changedX;
    gKarel.rowMatrix += changedY;
    if(SDL_RenderCopy(gRenderer, gKarel.texture, 0, gKarel.positionRectangle) < 0){
        fprintf(stderr, "\n%s - Chyba pri renderovani textury Karla na nove pozici. SDL Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    SDL_RenderPresent(gRenderer);
    return true;
}

/**
 * @brief Obnovení pozice, na které se robot Karel aktuálně nachází.
 * @return Návratová hodnota \b true dajde-li k úspěšnému překreslení pozice města v programovém rozhraní. Jinak je návratová hodnota \b false.
 * @warning  Nový obraz je vykreslován pomocí renderu.
 */
bool refreshCurrentPosition(){
    if(SDL_SetRenderDrawColor(gRenderer, 239, 228, 176, 255) < 0){
        fprintf(stderr, "\n%s - Chyba pri nastaveni barvy, pro prekresleni stavajiciho pole, na kterem se robot Karel nachazi. SDL Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    if(SDL_RenderFillRect(gRenderer, gKarel.positionRectangle) < 0){
        fprintf(stderr, "\n%s - Chyba pri renderovani ctverce, pro prekresleni stavajiciho pole, na kterem se robot Karel nachazi. SDL Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    if((gKarel.rowMatrix == gKarel.houseRow) && (gKarel.columnMatrix == gKarel.houseColumn)){
        if(SDL_RenderCopy(gRenderer, gTexturesOfKarelAndMap[TEXTURE_HOUSE], 0, gKarel.positionRectangle) < 0){
            fprintf(stderr, "\n%s - Chyba pri renderovani domecku, pro prekresleni stavajiciho pole, na kterem se robot Karel nachazi. SDL Error: %s", getTime(), SDL_GetError());
            gErrorsInternal++;
            return false;
        }
    }
    SDL_RenderCopy(gRenderer, returnTextureOfMap(gSemanticMatrix[gKarel.rowMatrix][gKarel.columnMatrix]), 0, gKarel.positionRectangle);
    if(SDL_RenderCopy(gRenderer, gKarel.texture, 0, gKarel.positionRectangle) < 0){
        fprintf(stderr, "\n%s - Chyba pri renderovani textury Karla, pro prekresleni stavajiciho pole, na kterem se robot Karel nachazi. SDL Error: %s", getTime(), SDL_GetError());
        gErrorsInternal++;
        return false;
    }
    SDL_RenderPresent(gRenderer);
    return true;
}

/**
 * @brief Kontrola zda se na dané pozici nachází zeď.
 * @param changeX Pole města definované na šířku, které má být prověřeno.
 * @param changeY Pole města definované na výšku, které má být prověřeno.
 * @return Nachází-li se na dané pozici zeď, je návratová hodnota \b true. Jinak je vrácena hodnota \b false.
 */
bool isFrontBlocked(int changeX, int changeY){
    if(crossingTheBorder(gKarel.rowMatrix + changeY, gKarel.columnMatrix + changeX, gPlayGroundWidht, gPlayGroundHeight)){
        return true;
    }
    if(gSemanticMatrix[gKarel.rowMatrix + changeY][gKarel.columnMatrix + changeX] == WALL){
        return true;
    }
    return false;
}

/**
 * @brief Určení nových souřadnice v závislosti na směru pro danou funkci.
 * @param direct Směr, pro který se přepočítávájí stávající souřadnice
 * @param function Funkce, pro kterou jsou přepočítané souřadnice vstupními parametry.
 * @return Návratovou hodnotou je návratová hodnota funkce definovavé v parametru \b function.
 */
bool determiningTheNewPositionInDirection(direction direct, bool (*function)()){
    switch(direct){
        case UP:
            return function(0, -1);
            break;

        case DOWN:
            return function(0, 1);
            break;

        case LEFT:
            return function(-1, 0);
            break;

        case RIGHT:
            return function(1, 0);
            break;

        default:
            break;
    }
    return false;
}

/**
 * @brief Je zjištěn aktuální lokální čas na tomto počítači.
 * @return Návratovou hodnotou je pole znaků charakterizující časový formát zjištěného času.
 */
char *getTime(){
    char hour[3];
    char min[3];
    char sec[3];
    char minSec[4];

    #ifdef _WIN32
        SYSTEMTIME timeWin;
        GetLocalTime(&timeWin);

        sprintf(hour,"%.2d", timeWin.wHour);
        sprintf(min,"%.2d", timeWin.wMinute);
        sprintf(sec,"%.2d", timeWin.wSecond);
        sprintf(minSec,"%.3d", timeWin.wMilliseconds);
    #else
        time_t second;
        struct tm *localTime;
        struct timespec timeSpecific;

        second = time(NULL);
        localTime = localtime(&second);
        clock_gettime(CLOCK_REALTIME, &timeSpecific);
        long ms = round(timeSpecific.tv_nsec / 1.0e6);

        sprintf(hour,"%.2i", localTime->tm_hour);
        sprintf(min,"%.2i", localTime->tm_min);
        sprintf(sec,"%.2i", localTime->tm_sec);
        sprintf(minSec,"%.3ld", ms);
    #endif

    strcpy(gTimeFormat, hour);
    strncat(gTimeFormat, ":", 1);
    strncat(gTimeFormat, min, 2);
    strncat(gTimeFormat, ":", 1);
    strncat(gTimeFormat, sec, 2);
    strncat(gTimeFormat, ",", 1);
    strncat(gTimeFormat, minSec,3);

    return gTimeFormat;
}